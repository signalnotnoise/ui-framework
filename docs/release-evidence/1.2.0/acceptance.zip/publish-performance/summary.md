# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,217.63 | 3,225.20 | 0.24% | within budget |
| full-list | Milliseconds | 4,167.32 | 3,022.21 | -27.48% | within budget |
| full-list | MountAllocatedBytes | 336,502,368.00 | 333,430,136.00 | -0.91% | within budget |
| full-list | AllocatedBytes | 623,476,480.00 | 469,331,824.00 | -24.72% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 260.27 | 263.95 | 1.41% | within budget |
| virtualized | Milliseconds | 691.81 | 347.08 | -49.83% | within budget |
| virtualized | MountAllocatedBytes | 9,664,336.00 | 9,572,768.00 | -0.95% | within budget |
| virtualized | AllocatedBytes | 62,649,792.00 | 48,852,144.00 | -22.02% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 3,047.66 | 3,202.13 | 5.07% | within budget |
| themed-full-list | Milliseconds | 7,474.11 | 3,066.81 | -58.97% | within budget |
| themed-full-list | MountAllocatedBytes | 327,710,432.00 | 328,439,760.00 | 0.22% | within budget |
| themed-full-list | AllocatedBytes | 1,075,281,624.00 | 474,063,208.00 | -55.91% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,304.71 | 1,349.39 | 3.42% | within budget |
| layout-editors | Milliseconds | 8,237.18 | 7,946.88 | -3.52% | within budget |
| layout-editors | MountAllocatedBytes | 125,467,056.00 | 120,800,080.00 | -3.72% | within budget |
| layout-editors | AllocatedBytes | 1,161,706,080.00 | 1,124,941,016.00 | -3.16% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
