# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,639.99 | 3,792.97 | 4.20% | within budget |
| full-list | Milliseconds | 4,199.95 | 3,409.92 | -18.81% | within budget |
| full-list | MountAllocatedBytes | 336,428,400.00 | 333,483,072.00 | -0.88% | within budget |
| full-list | AllocatedBytes | 623,799,112.00 | 469,759,264.00 | -24.69% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 420.12 | 394.14 | -6.18% | within budget |
| virtualized | Milliseconds | 853.07 | 405.41 | -52.48% | within budget |
| virtualized | MountAllocatedBytes | 9,679,880.00 | 9,595,624.00 | -0.87% | within budget |
| virtualized | AllocatedBytes | 63,211,088.00 | 48,890,200.00 | -22.66% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 4,144.46 | 4,547.33 | 9.72% | within budget |
| themed-full-list | Milliseconds | 9,630.36 | 5,069.21 | -47.36% | within budget |
| themed-full-list | MountAllocatedBytes | 327,580,336.00 | 329,048,496.00 | 0.45% | within budget |
| themed-full-list | AllocatedBytes | 1,069,558,864.00 | 473,509,048.00 | -55.73% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,877.89 | 1,883.60 | 0.30% | within budget |
| layout-editors | Milliseconds | 9,619.07 | 9,021.91 | -6.21% | within budget |
| layout-editors | MountAllocatedBytes | 125,473,976.00 | 120,809,232.00 | -3.72% | within budget |
| layout-editors | AllocatedBytes | 1,161,568,304.00 | 1,124,890,576.00 | -3.16% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
