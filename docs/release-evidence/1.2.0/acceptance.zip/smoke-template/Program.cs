using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using UI_Framework;
using UI_Framework.Wpf;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        var glyph = new VectorIcon("M 12,4 V 20 M 4,12 H 20", strokeWidth: 2);
        var theme = new ThemeTokens { Spacing = new() { Medium = 18 }, Typography = new() { Body = 20 }, Icons = new() { LabelGap = 14 }, Radii = new() { Large = 16 } };
        var clicks = 0;
        var view = UI.Button(glyph, "Add item", () => clicks++).FontSize(theme.Typography.Body).Padding(theme.Spacing.Medium).CornerRadius(theme.Radii.Large);
        using var host = new ViewHost(() => view);
        ThemeStyles.Apply(host, theme);
        var window = new Window { Content = host, Width = 400, Height = 220, Left = -10000, Top = -10000, ShowInTaskbar = false, ShowActivated = false };
        try
        {
            window.Show(); window.UpdateLayout();
            var frame = (Border)host.Content;
            var button = (Button)frame.Child;
            if (frame.Padding.Left != theme.Spacing.Medium || frame.CornerRadius.TopLeft != theme.Radii.Large || button.FontSize != theme.Typography.Body) throw new Exception("Token composition failed.");
            var content = (Panel)button.Content;
            var icon = (FrameworkElement)content.Children[0];
            if (icon.Margin.Right != theme.Icons.LabelGap) throw new Exception("Scoped icon gap failed.");
            var peer = new ButtonAutomationPeer(button);
            if (peer.GetName() != "Add item") throw new Exception("Labelled icon button accessibility failed.");
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            if (clicks != 1) throw new Exception("Button callback failed.");
            ThemeStyles.Apply(host, theme with { Icons = theme.Icons with { LabelGap = 9 } });
            window.UpdateLayout();
            if (icon.Margin.Right != 9 || !ReferenceEquals(content, button.Content)) throw new Exception("Retained scoped token update failed.");
            view = UI.IconButton(glyph, "Add", () => clicks += 10);
            host.Refresh(); window.UpdateLayout();
            if (!ReferenceEquals(frame, host.Content) || !ReferenceEquals(button, frame.Child) || icon.Margin.Right != 0 || peer.GetName() != "Add") throw new Exception("Icon-only update failed.");
            host.Dispose();
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            if (clicks != 1) throw new Exception("Detached callback remained active.");
            using var standalone = new ViewHost(() => UI.Icon(glyph, theme.Icons.Medium).AccessibilityLabel("Additional items"));
            if (UIElementAutomationPeer.CreatePeerForElement((FrameworkElement)((Border)standalone.Content).Child)!.GetName() != "Additional items") throw new Exception("Standalone icon name failed.");
            var assemblies = new[] { typeof(View).Assembly, typeof(ViewHost).Assembly }.Select(a => new { Name = a.GetName().Name, Version = a.GetName().Version!.ToString(), Sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))) }).ToArray();
            File.WriteAllText(args[0], JsonSerializer.Serialize(new { Passed = true, Assemblies = assemblies }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine("PASS: packaged icons, tokens, scoped updates, native names, callbacks and cleanup.");
        }
        finally { window.Close(); }
    }
}
