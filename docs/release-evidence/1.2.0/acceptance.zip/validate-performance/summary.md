# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 5,968.57 | 5,992.24 | 0.40% | within budget |
| full-list | Milliseconds | 6,240.76 | 4,817.24 | -22.81% | within budget |
| full-list | MountAllocatedBytes | 336,107,480.00 | 333,214,888.00 | -0.86% | within budget |
| full-list | AllocatedBytes | 619,636,256.00 | 467,714,656.00 | -24.52% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 436.12 | 446.00 | 2.27% | within budget |
| virtualized | Milliseconds | 1,473.09 | 762.29 | -48.25% | within budget |
| virtualized | MountAllocatedBytes | 9,664,304.00 | 9,572,768.00 | -0.95% | within budget |
| virtualized | AllocatedBytes | 63,165,376.00 | 48,852,144.00 | -22.66% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 5,764.00 | 5,994.85 | 4.00% | within budget |
| themed-full-list | Milliseconds | 11,708.83 | 5,371.41 | -54.13% | within budget |
| themed-full-list | MountAllocatedBytes | 327,325,464.00 | 327,873,368.00 | 0.17% | within budget |
| themed-full-list | AllocatedBytes | 1,064,409,496.00 | 472,111,176.00 | -55.65% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 3,056.66 | 3,070.10 | 0.44% | within budget |
| layout-editors | Milliseconds | 15,402.75 | 15,112.26 | -1.89% | within budget |
| layout-editors | MountAllocatedBytes | 125,462,496.00 | 120,792,744.00 | -3.72% | within budget |
| layout-editors | AllocatedBytes | 1,156,211,488.00 | 1,124,656,632.00 | -2.73% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
