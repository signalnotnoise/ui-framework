import sys,json,hashlib,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
folder=Path(sys.argv[1]); output=Path(sys.argv[2]); expected=sys.argv[3] if len(sys.argv)>3 else None
results=[]
for path in sorted(folder.glob('*.nupkg')):
 with zipfile.ZipFile(path) as z:
  ns=ET.fromstring(z.read(next(n for n in z.namelist() if n.endswith('.nuspec'))))
  version=next(e.text for e in ns.iter() if e.tag.endswith('}version'))
  repo=next((e.attrib for e in ns.iter() if e.tag.endswith('}repository')), {})
  assert version=='1.2.0', (path,version)
  if expected: assert repo.get('commit')==expected,(path,repo)
  readme=z.read(next(n for n in z.namelist() if n.lower()=='readme.md'))
  assert b'--version 1.2.0' in readme and b'This is an evaluation release' not in readme
  dlls={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.dll')}
  results.append(dict(package=path.name,version=version,repository=repo,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),readmeSha256=hashlib.sha256(readme).hexdigest(),dlls=dlls))
assert len(results)==2
output.write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print('Verified both package versions, READMEs and assembly manifests.')
