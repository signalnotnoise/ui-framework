# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 6,163.53 | 6,239.88 | 1.24% | within budget |
| full-list | Milliseconds | 6,448.96 | 5,053.75 | -21.63% | within budget |
| full-list | MountAllocatedBytes | 336,072,856.00 | 332,899,760.00 | -0.94% | within budget |
| full-list | AllocatedBytes | 619,664,184.00 | 466,189,600.00 | -24.77% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 465.49 | 489.23 | 5.10% | within budget |
| virtualized | Milliseconds | 1,396.88 | 762.27 | -45.43% | within budget |
| virtualized | MountAllocatedBytes | 9,664,336.00 | 9,544,160.00 | -1.24% | within budget |
| virtualized | AllocatedBytes | 63,165,376.00 | 48,350,936.00 | -23.45% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 6,229.85 | 6,402.77 | 2.78% | within budget |
| themed-full-list | Milliseconds | 12,768.35 | 5,914.01 | -53.68% | within budget |
| themed-full-list | MountAllocatedBytes | 327,358,416.00 | 327,673,416.00 | 0.10% | within budget |
| themed-full-list | AllocatedBytes | 1,064,414,824.00 | 470,971,488.00 | -55.75% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 3,260.47 | 3,192.70 | -2.08% | within budget |
| layout-editors | Milliseconds | 16,652.15 | 16,340.56 | -1.87% | within budget |
| layout-editors | MountAllocatedBytes | 125,471,192.00 | 120,780,864.00 | -3.74% | within budget |
| layout-editors | AllocatedBytes | 1,156,379,272.00 | 1,113,158,264.00 | -3.74% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
