# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 6,076.49 | 5,974.52 | -1.68% | within budget |
| full-list | Milliseconds | 6,266.38 | 4,833.55 | -22.87% | within budget |
| full-list | MountAllocatedBytes | 336,172,456.00 | 333,005,384.00 | -0.94% | within budget |
| full-list | AllocatedBytes | 619,634,160.00 | 466,116,776.00 | -24.78% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 425.61 | 439.57 | 3.28% | within budget |
| virtualized | Milliseconds | 1,284.81 | 697.57 | -45.71% | within budget |
| virtualized | MountAllocatedBytes | 9,664,304.00 | 9,544,160.00 | -1.24% | within budget |
| virtualized | AllocatedBytes | 63,165,376.00 | 48,350,936.00 | -23.45% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 5,880.88 | 5,972.64 | 1.56% | within budget |
| themed-full-list | Milliseconds | 12,078.98 | 5,409.31 | -55.22% | within budget |
| themed-full-list | MountAllocatedBytes | 327,365,608.00 | 327,567,408.00 | 0.06% | within budget |
| themed-full-list | AllocatedBytes | 1,064,411,640.00 | 470,916,920.00 | -55.76% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 3,053.81 | 3,038.71 | -0.49% | within budget |
| layout-editors | Milliseconds | 15,167.85 | 14,915.77 | -1.66% | within budget |
| layout-editors | MountAllocatedBytes | 125,478,376.00 | 120,780,184.00 | -3.74% | within budget |
| layout-editors | AllocatedBytes | 1,156,076,664.00 | 1,113,445,264.00 | -3.69% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
