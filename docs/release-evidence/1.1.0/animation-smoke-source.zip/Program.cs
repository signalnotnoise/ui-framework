using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using UI_Framework;
using UI_Framework.Wpf;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        var changed = new State<bool>(false);
        var spec = new AnimationSpec(TimeSpan.FromMilliseconds(160), AnimationEasing.EaseOut);
        using var host = new ViewHost(() => UI.Text("Package animation")
            .Opacity(changed.Value ? .25 : 1).Translate(changed.Value ? 12 : 0, changed.Value ? -6 : 0)
            .Animate(AnimationProperties.Opacity | AnimationProperties.Translation, spec));
        var window = new Window { Content = host, Width = 300, Height = 150, Left = -10000,
            Top = -10000, ShowInTaskbar = false, ShowActivated = false };
        try
        {
            AnimationSettings.SetIsEnabled(host, false);
            window.Show(); window.UpdateLayout();
            var frame = (Border)host.Content;
            if (frame.Opacity != 1 || frame.HasAnimatedProperties) throw new Exception("Initial target failed.");
            changed.Value = true; host.Refresh();
            if (!ReferenceEquals(frame, host.Content) || frame.Opacity != .25 || frame.HasAnimatedProperties
                || frame.RenderTransform is not TranslateTransform { X: 12, Y: -6 })
                throw new Exception("Retained targets or motion suppression failed.");
            AnimationSettings.SetIsEnabled(host, true);
            changed.Value = false; host.Refresh();
            if (frame.HasAnimatedProperties != SystemParameters.ClientAreaAnimation)
                throw new Exception("Windows motion preference was not honored.");
            AnimationSettings.SetIsEnabled(host, false);
            if (frame.HasAnimatedProperties || frame.Opacity != 1) throw new Exception("Cancellation failed.");
            host.Dispose();
            var assemblies = new[] { typeof(View).Assembly, typeof(ViewHost).Assembly }.Select(a => new
            {
                Name = a.GetName().Name, Version = a.GetName().Version!.ToString(),
                Sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location)))
            }).ToArray();
            File.WriteAllText(args[0], JsonSerializer.Serialize(new { Passed = true,
                WindowsMotionEnabled = SystemParameters.ClientAreaAnimation, Assemblies = assemblies },
                new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine("PASS: packaged animation APIs, retained targets, motion policy and cleanup.");
        }
        finally { window.Close(); }
    }
}
