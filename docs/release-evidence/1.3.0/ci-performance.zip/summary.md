# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 5,508.45 | 5,418.37 | -1.64% | within budget |
| full-list | Milliseconds | 5,722.13 | 4,544.70 | -20.58% | within budget |
| full-list | MountAllocatedBytes | 336,122,896.00 | 333,409,000.00 | -0.81% | within budget |
| full-list | AllocatedBytes | 620,222,608.00 | 469,437,376.00 | -24.31% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 395.45 | 405.28 | 2.49% | within budget |
| virtualized | Milliseconds | 1,342.52 | 666.86 | -50.33% | within budget |
| virtualized | MountAllocatedBytes | 9,664,304.00 | 9,599,968.00 | -0.67% | within budget |
| virtualized | AllocatedBytes | 63,179,104.00 | 49,344,976.00 | -21.90% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 5,496.07 | 5,903.29 | 7.41% | within budget |
| themed-full-list | Milliseconds | 10,851.99 | 5,948.69 | -45.18% | within budget |
| themed-full-list | MountAllocatedBytes | 327,368,616.00 | 328,351,360.00 | 0.30% | within budget |
| themed-full-list | AllocatedBytes | 1,068,132,832.00 | 474,920,856.00 | -55.54% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 2,845.96 | 2,785.79 | -2.11% | within budget |
| layout-editors | Milliseconds | 13,240.45 | 12,704.99 | -4.04% | within budget |
| layout-editors | MountAllocatedBytes | 125,470,616.00 | 120,816,424.00 | -3.71% | within budget |
| layout-editors | AllocatedBytes | 1,161,142,008.00 | 1,125,505,536.00 | -3.07% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
