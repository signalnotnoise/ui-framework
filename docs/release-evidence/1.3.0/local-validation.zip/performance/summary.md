# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,823.28 | 3,947.10 | 3.24% | within budget |
| full-list | Milliseconds | 4,601.12 | 3,535.82 | -23.15% | within budget |
| full-list | MountAllocatedBytes | 336,429,880.00 | 333,744,960.00 | -0.80% | within budget |
| full-list | AllocatedBytes | 623,730,032.00 | 470,587,872.00 | -24.55% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 394.77 | 427.32 | 8.25% | within budget |
| virtualized | Milliseconds | 848.93 | 418.03 | -50.76% | within budget |
| virtualized | MountAllocatedBytes | 9,679,768.00 | 9,624,128.00 | -0.57% | within budget |
| virtualized | AllocatedBytes | 63,212,864.00 | 49,392,784.00 | -21.86% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 3,923.38 | 4,199.72 | 7.04% | within budget |
| themed-full-list | Milliseconds | 8,532.82 | 4,245.60 | -50.24% | within budget |
| themed-full-list | MountAllocatedBytes | 327,711,656.00 | 329,360,640.00 | 0.50% | within budget |
| themed-full-list | AllocatedBytes | 1,072,022,768.00 | 475,120,232.00 | -55.68% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,879.20 | 1,792.90 | -4.59% | within budget |
| layout-editors | Milliseconds | 8,856.72 | 8,695.39 | -1.82% | within budget |
| layout-editors | MountAllocatedBytes | 125,481,992.00 | 120,834,648.00 | -3.70% | within budget |
| layout-editors | AllocatedBytes | 1,161,585,624.00 | 1,125,677,776.00 | -3.09% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
