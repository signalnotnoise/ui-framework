# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 4,540.38 | 4,510.99 | -0.65% | within budget |
| full-list | Milliseconds | 4,951.16 | 3,732.78 | -24.61% | within budget |
| full-list | MountAllocatedBytes | 336,262,904.00 | 333,472,760.00 | -0.83% | within budget |
| full-list | AllocatedBytes | 622,537,744.00 | 470,007,752.00 | -24.50% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 335.43 | 340.74 | 1.58% | within budget |
| virtualized | Milliseconds | 936.44 | 502.59 | -46.33% | within budget |
| virtualized | MountAllocatedBytes | 9,664,336.00 | 9,601,320.00 | -0.65% | within budget |
| virtualized | AllocatedBytes | 63,165,376.00 | 49,350,552.00 | -21.87% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 4,367.61 | 4,563.52 | 4.49% | within budget |
| themed-full-list | Milliseconds | 9,463.08 | 4,386.12 | -53.65% | within budget |
| themed-full-list | MountAllocatedBytes | 327,357,512.00 | 328,451,720.00 | 0.33% | within budget |
| themed-full-list | AllocatedBytes | 1,069,146,312.00 | 474,570,360.00 | -55.61% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 2,175.92 | 2,178.07 | 0.10% | within budget |
| layout-editors | Milliseconds | 10,871.74 | 10,641.38 | -2.12% | within budget |
| layout-editors | MountAllocatedBytes | 125,468,552.00 | 120,820,592.00 | -3.70% | within budget |
| layout-editors | AllocatedBytes | 1,161,283,056.00 | 1,125,555,096.00 | -3.08% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
