import importlib.util,json,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path('artifacts/fw018-automation-roots-2026-11-15')
spec=importlib.util.spec_from_file_location('native','tools/Summarize-NativeMemory.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
results=[]
for name in ['1-clean','1-warm','2-warm','2-clean','3-clean','3-warm']:
 r=json.loads((root/(name+'.json')).read_text(encoding='utf-8-sig'));assert r['AutomationWarmup']==name.endswith('warm')
 measured=native.validate(r,dict(rows=500,cycles=4,warmups=3,batches=180,reportingProtocol='bounded-sample-files-v1',inputObservation='window-routed-input-v1'))
 raw=[json.loads(p.read_text()) for p in sorted((root/(name+'.json.samples')).glob('*.json'))];assert raw==r['Result']['Samples'] and len(raw)==183
 metrics={}
 for k in native.METRICS:
  values=[s[k] for s in measured]
  metrics[k]=dict(first=values[0],last=values[-1],change=values[-1]-values[0],median=statistics.median(values),quarters=[statistics.median(values[i:i+45]) for i in range(0,180,45)])
 results.append(dict(case=name,metrics=metrics,input=native.input_summary(measured),lastInput=raw[-1]['Input']))
summary=dict(releaseGate=False,memoryBudgetApproved=False,rawSamplesValidated=1098,workspaceCycles=4392,order=[r['case'] for r in results],runs=results)
(root/'soak-comparison.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
for r in results:print(r['case'],{k:[v['first'],v['last']] for k,v in r['metrics'].items() if k in ('CollectedManagedBytes','HandleCount','GdiObjects','UserObjects')},r['input'])
