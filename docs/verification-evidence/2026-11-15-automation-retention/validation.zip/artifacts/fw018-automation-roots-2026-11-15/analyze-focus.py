import importlib.util,json,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path('artifacts/fw018-automation-roots-2026-11-15')
spec=importlib.util.spec_from_file_location('native','tools/Summarize-NativeMemory.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
results=[]
for name in ['focus-control-1','focus-1','focus-2','focus-control-2']:
 r=json.loads((root/(name+'.json')).read_text());assert not r['AutomationWarmup']
 samples=native.validate(r,dict(rows=500,cycles=4,warmups=3,batches=180,reportingProtocol='bounded-sample-files-v1',inputObservation='window-routed-input-v1'))
 raw=[json.loads(p.read_text()) for p in sorted((root/(name+'.json.samples')).glob('*.json'))];assert raw==r['Result']['Samples'] and len(raw)==183
 assert r['Result']['FocusAtBatch']==(-1 if 'control' in name else 60)
 metrics={k:dict(first=samples[0][k],last=samples[-1][k],change=samples[-1][k]-samples[0][k]) for k in native.METRICS}
 transitions=[]
 for a,b in zip(raw,raw[1:]):
  if any(a[k]!=b[k] for k in ('GdiObjects','UserObjects')) or a['Input']['Activations']!=b['Input']['Activations']:
   transitions.append({k:b[k] for k in ('Batch','HandleCount','GdiObjects','UserObjects','CollectedManagedBytes','Input')})
 results.append(dict(case=name,metrics=metrics,transitions=transitions,input=native.input_summary(samples),afterShutdown=r['AfterDispatcherShutdown']))
(root/'focus-comparison.json').write_text(json.dumps(dict(releaseGate=False,runs=results,rawSamplesValidated=732,workspaceCycles=2928),indent=2),encoding='utf-8')
for r in results:print(r['case'],{k:v for k,v in r['metrics'].items() if k in ('CollectedManagedBytes','HandleCount','GdiObjects','UserObjects')},'transitions',[(x['Batch'],x['GdiObjects'],x['UserObjects'],x['Input']['Activations']) for x in r['transitions']])
