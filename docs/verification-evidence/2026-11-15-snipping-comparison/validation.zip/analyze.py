import json,statistics,importlib.util,sys
sys.dont_write_bytecode=True
from pathlib import Path
root=Path('artifacts/fw018-snipping-2026-11-15')
spec=importlib.util.spec_from_file_location('native','tools/Summarize-NativeMemory.py')
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
campaign=dict(rows=500,cycles=4,warmups=3,batches=600,reportingProtocol='bounded-sample-files-v1',inputObservation='window-routed-input-v1')
results=[]
for name in ['manual-capture','clean-matched']:
 r=json.loads((root/(name+'.json')).read_text(encoding='utf-8-sig'))
 native.validate(r,campaign)
 assert r['Passed'] and r['DispatcherShutdownFinished'] and r['CleanupPolicyClosed']
 samples=r['Result']['Samples'];raw=[json.loads(p.read_text(encoding='utf-8-sig')) for p in sorted((root/(name+'.json.samples')).glob('*.json'))]
 assert raw==samples and len(samples)==603
 assert all(all(v==0 for v in s['Alive'].values()) and s['NativeBytes']==0 and s['Created']==s['Released'] for s in samples)
 measured=[s for s in samples if not s['Warmup']];assert len(measured)==600
 metrics={}
 for key in ['CollectedManagedBytes','HandleCount','GdiObjects','UserObjects','BatchMilliseconds','UiAllocatedBytes']:
  values=[s[key] for s in measured]
  metrics[key]=dict(first=values[0],last=values[-1],change=values[-1]-values[0],median=statistics.median(values),maximum=max(values),quarters=[statistics.median(values[i:i+150]) for i in range(0,600,150)])
 results.append(dict(name=name,metrics=metrics,lastInput=samples[-1]['Input'],captureInterval=[47,91] if name=='manual-capture' else None,intervalMedian=statistics.median(s['BatchMilliseconds'] for s in samples if 47<=s['Batch']<=91),cycles=603*4))
(root/'comparison.json').write_text(json.dumps(dict(results=results,releaseGate=False,limitations='One pair, capture first; manual capture timing is bounded by request and receipt, not exact. Earlier automation-confounded controls preserved separately.'),indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
