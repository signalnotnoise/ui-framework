import importlib.util,json,shutil,tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location("focus","tools/Summarize-FocusComparison.py"); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
source=Path("artifacts/fw018-plain-wpf-2026-11-15/comparison")
assert m.summarize(source)["focusAcquisitions"]==540
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)/"comparison"; shutil.copytree(source,root)
 target=root/"2-Plain-focus"/"result.json"; original=target.read_text(); data=json.loads(original)
 for change in [dict(VerifiedFocus=89),dict(Survivors=1),dict(Assemblies=data["Assemblies"]+["UI Framework"])]:
  target.write_text(json.dumps(data|change))
  try:m.summarize(root)
  except AssertionError:pass
  else:raise RuntimeError("Accepted invalid evidence")
 target.write_text(original)
 sample=next((root/"2-Plain-focus").glob("*-cycle-closed.json")); sample.unlink()
 try:m.summarize(root)
 except AssertionError:pass
 else:raise RuntimeError("Accepted missing cycle")
print("PASS: complete comparison accepted; missed focus, survivors, contaminated plain build and missing cycle rejected")
