using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

internal static class Program
{
    [DllImport("dbghelp.dll", SetLastError = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool MiniDumpWriteDump(SafeProcessHandle process, uint processId,
        SafeFileHandle file, uint flags, nint exception, nint userStreams, nint callback);

    private static void Main(string[] args)
    {
        if (args.Length != 2) throw new ArgumentException("Usage: MemoryDumpCollector <owned-process-id> <new-dump-path>");
        var pid = int.Parse(args[0]);
        if (pid == Environment.ProcessId) throw new ArgumentException("Capture from a separate process.");
        using var process = Process.GetProcessById(pid);
        using var file = new FileStream(Path.GetFullPath(args[1]), FileMode.CreateNew, FileAccess.Write, FileShare.None);
        // FullMemory | HandleData | ThreadInfo: documented MINIDUMP_TYPE flags.
        if (!MiniDumpWriteDump(process.SafeHandle, (uint)pid, file.SafeFileHandle, 0x1006, 0, 0, 0))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        Console.WriteLine($"Captured process {pid} with full memory, handle types and thread information.");
    }
}
