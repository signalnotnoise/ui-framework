# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,575.43 | 3,513.52 | -1.73% | within budget |
| full-list | Milliseconds | 3,710.44 | 2,880.56 | -22.37% | within budget |
| full-list | MountAllocatedBytes | 336,412,224.00 | 333,025,936.00 | -1.01% | within budget |
| full-list | AllocatedBytes | 623,445,096.00 | 467,196,512.00 | -25.06% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 375.32 | 375.50 | 0.05% | within budget |
| virtualized | Milliseconds | 770.98 | 379.46 | -50.78% | within budget |
| virtualized | MountAllocatedBytes | 9,679,120.00 | 9,537,544.00 | -1.46% | within budget |
| virtualized | AllocatedBytes | 63,181,184.00 | 47,859,240.00 | -24.25% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 3,373.22 | 3,518.84 | 4.32% | within budget |
| themed-full-list | Milliseconds | 7,260.92 | 3,407.77 | -53.07% | within budget |
| themed-full-list | MountAllocatedBytes | 327,619,408.00 | 328,363,088.00 | 0.23% | within budget |
| themed-full-list | AllocatedBytes | 1,073,695,728.00 | 471,664,920.00 | -56.07% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,681.16 | 1,678.71 | -0.15% | within budget |
| layout-editors | Milliseconds | 7,992.74 | 7,595.75 | -4.97% | within budget |
| layout-editors | MountAllocatedBytes | 125,474,664.00 | 120,768,624.00 | -3.75% | within budget |
| layout-editors | AllocatedBytes | 1,161,744,824.00 | 1,123,385,640.00 | -3.30% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
