param([switch]$NoRestore)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
Push-Location $projectRoot
try {
    python tools/Update-SkillReference.py --check
    if ($LASTEXITCODE -ne 0) { throw 'Skill references are stale.' }
    if (-not $NoRestore) {
        dotnet restore 'UI Framework.slnx' --disable-build-servers
        if ($LASTEXITCODE -ne 0) { throw 'Restore failed.' }
    }
    dotnet build 'UI Framework.slnx' -c Release --no-restore --disable-build-servers -m:1 -warnaserror
    if ($LASTEXITCODE -ne 0) { throw 'Release build failed.' }
    dotnet test 'tests/UI Framework.Checks/UI Framework.Checks.csproj' -c Release --no-build --no-restore --results-directory artifacts/release-validation/tests --logger 'trx;LogFileName=regression.trx' --blame-hang-timeout 2m
    if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed.' }
    $logViewerOutput = 'artifacts/release-validation/log-viewer-' + [Guid]::NewGuid().ToString('N')
    dotnet 'samples/LogViewer/bin/Release/net10.0-windows/LogViewer.dll' --verify $logViewerOutput
    if ($LASTEXITCODE -ne 0) { throw 'Log viewer sample verification failed.' }
    $reportingOutput = 'artifacts/release-validation/reporting-' + [Guid]::NewGuid().ToString('N')
    dotnet 'tests/ReportingRetentionChecks/bin/Release/net10.0/ReportingRetentionChecks.dll' $reportingOutput
    if ($LASTEXITCODE -ne 0) { throw 'Measurement reporting retention controls failed.' }
    & (Join-Path $PSScriptRoot 'Update-KnowledgeGraph.ps1') -Check
    & (Join-Path $PSScriptRoot 'Test-Documentation.ps1')
    dotnet 'samples/Counter/bin/Release/net10.0-windows/Counter.dll' --visual-check
    if ($LASTEXITCODE -ne 0) { throw 'Visual stress checks failed.' }
    dotnet 'samples/Counter/bin/Release/net10.0-windows/Counter.dll' --stress --report artifacts/release-validation/stress.json --snapshot artifacts/release-validation/dashboard.png
    if ($LASTEXITCODE -ne 0) { throw 'Full stress workload failed.' }
    $startupReport = 'artifacts/release-validation/startup-' + [Guid]::NewGuid().ToString('N') + '.json'
    dotnet 'samples/Counter/bin/Release/net10.0-windows/Counter.dll' --startup-check --report $startupReport
    if ($LASTEXITCODE -ne 0) { throw 'Actual-window startup, editing and disposal check failed.' }
    $nativeReport = 'artifacts/release-validation/native-window-' + [Guid]::NewGuid().ToString('N') + '.json'
    dotnet 'samples/NativeLifetime/bin/Release/net10.0-windows/NativeLifetime.dll' --mode window --report $nativeReport
    if ($LASTEXITCODE -ne 0) { throw 'Native real-window ownership and shutdown checks failed.' }
    $memoryReport = 'artifacts/release-validation/native-memory-' + [Guid]::NewGuid().ToString('N') + '/report.json'
    dotnet 'samples/NativeLifetime/bin/Release/net10.0-windows/NativeLifetime.dll' --mode memory --batches 1 --warmups 0 --cycles 1 --rows 100 --report $memoryReport
    if ($LASTEXITCODE -ne 0) { throw 'Short memory reporting isolation or fresh-directory check failed.' }
    Write-Output 'Release validation passed. This command does not publish anything.'
} finally {
    Pop-Location
}
