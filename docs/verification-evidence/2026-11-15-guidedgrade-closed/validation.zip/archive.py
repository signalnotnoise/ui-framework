from pathlib import Path
import hashlib, json, zipfile

root = Path('artifacts/fw018-guidedgrade-closed-2026-11-15')
dest = Path('docs/verification-evidence/2026-11-15-guidedgrade-closed')
dest.mkdir(parents=True, exist_ok=True)
entries = []
dumps = []
with zipfile.ZipFile(dest/'validation.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(root.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:
            continue
        name = p.relative_to(root).as_posix()
        if p.suffix == '.dmp':
            digest = hashlib.sha256()
            with p.open('rb') as f:
                for block in iter(lambda: f.read(8*1024*1024), b''):
                    digest.update(block)
            dumps.append(dict(path=name, bytes=p.stat().st_size, sha256=digest.hexdigest(), archived=False))
            print('Hashed local dump:', name, flush=True)
            continue
        data = p.read_bytes()
        archive.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(dest/'validation.zip') as archive:
    for entry in entries:
        data = archive.read(entry['path'])
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
(dest/'manifest.json').write_text(json.dumps(dict(entries=entries, localDumps=dumps, archiveSha256=hashlib.sha256((dest/'validation.zip').read_bytes()).hexdigest()), indent=2)+'\n')
print('Verified',len(entries),'archive entries;',len(dumps),'dumps retained locally')
