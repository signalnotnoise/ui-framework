from pathlib import Path
import json,importlib.util,mmap,sys,collections
sys.dont_write_bytecode=True
root=Path('artifacts/fw018-guidedgrade-closed-2026-11-15')
spec=importlib.util.spec_from_file_location('native','tools/Summarize-NativeMemory.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
spec=importlib.util.spec_from_file_location('attr','tools/Summarize-MemoryAttribution.py');attr=importlib.util.module_from_spec(spec);spec.loader.exec_module(attr)
results={}
for case in ['manual','control','thread-exit','thread-control-untouched']:
 p=root/case;r=json.loads((p/'report.json').read_text());samples=native.validate(r,dict(rows=500,cycles=4,warmups=3,batches=600,reportingProtocol='bounded-sample-files-v1',inputObservation='window-routed-input-v1'))
 raw=[json.loads(f.read_text()) for f in sorted((p/'report.json.samples').glob('*.json'))];assert raw==r['Result']['Samples'] and len(raw)==603
 audit=json.loads((p/'app-audit.json').read_text());assert all(not event['apps'] for event in audit)
 phases={}
 for phase in ['start','first-activation','end','quiescent','post-shutdown','post-thread']:
  f=p/(phase+'.dmp')
  if not f.exists():continue
  with f.open('rb') as stream:
   with mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as data:handles=attr.handles(data,True)
  g=json.loads((p/(phase+'.gdi.json')).read_text());w=json.loads((p/(phase+'.windows.json')).read_text())
  phases[phase]=dict(handles=handles,gdi=g,windows=w,gdiTypeCounts=dict(collections.Counter(o['Type'] for o in g['Objects'])))
 if case in ('control','thread-control-untouched'):assert not native.input_summary(samples)['observed']
 else:assert samples[-1]['Input']['Activations']==1 and samples[-1]['Input']['MouseButtons']==0 and samples[-1]['Input']['KeyDowns']==0
 if case in ('thread-exit','thread-control-untouched'):
  t=json.loads((p/'report.json.thread-exit.json').read_text());assert t['UiThreadExited'] and t['ExitCode']==0
 results[case]=dict(phases=phases,input=native.input_summary(samples),samples=len(raw),workspaceCycles=len(raw)*4,mounts=raw[-1]['Created'])
summary=dict(releaseGate=False,memoryBudgetApproved=False,GuidedGradeAbsentAtRecordedCheckpoints=True,rawSamplesValidated=2412,workspaceCycles=9648,runs=results)
(root/'analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
for case,r in results.items():
 print(case)
 for phase,s in r['phases'].items():print(phase,'handles',s['handles']['count'],'GDI',s['gdi']['ReportedGdiObjects'],'enumerated',s['gdi']['Enumerated'],'USER',s['windows']['UserObjects'],'windows',[(w['Class'],w['Module']) for w in s['windows']['Windows']] if phase.startswith('post') else len(s['windows']['Windows']))
