import importlib.util
import json
import statistics
import sys
from pathlib import Path

sys.dont_write_bytecode = True
root = Path.cwd()
spec = importlib.util.spec_from_file_location('native', root / 'tools/Summarize-NativeMemory.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def stats(values):
    n = len(values)
    assert n >= 4 and n % 4 == 0
    q = n // 4
    quarters = [statistics.median(values[i*q:(i+1)*q]) for i in range(4)]
    return dict(first=values[0], last=values[-1], change=values[-1]-values[0],
                minimum=min(values), maximum=max(values), quarterMedians=quarters,
                lastQuarterMedianChange=quarters[-1]-quarters[-2])

results, raw_counts, library_hashes = [], [], []
native_names = ['fw018-long-native-500-2026-11-15', 'fw018-long-native-5000-2026-11-15',
                'fw018-long-input-native-500-2026-11-15']
for name in native_names:
    directory = root / 'artifacts' / name
    campaign = read(directory / 'campaign.json')
    native.summarize(directory)  # Original ownership, negative-control and retention checks.
    for index in range(1, campaign['repetitions'] + 1):
        path = directory / f'memory-{index}.json'
        report = read(path)
        measured = native.validate(report, campaign)
        raw = [read(p) for p in sorted((directory / f'memory-{index}.json.samples').glob('*.json'))]
        assert raw == report['Result']['Samples']
        raw_counts.append(dict(case=f'{name}/memory-{index}', matched=len(raw)))
        results.append(dict(case=f'{name}/memory-{index}', kind='native', rows=campaign['rows'],
            measured=len(measured), workspaceCycles=len(raw)*campaign['cycles'],
            mounts=raw[-1]['Created'],
            input=None if not campaign.get('inputObservation') else native.input_summary(measured),
            metrics={k: stats([s[k] for s in measured]) for k in native.METRICS}))
    negative = read(directory/'negative.json')
    raw = [read(p) for p in sorted((directory/'negative.json.samples').glob('*.json'))]
    assert raw == negative['Result']['Samples']
    raw_counts.append(dict(case=f'{name}/negative', matched=len(raw)))

directory = root/'artifacts/fw018-long-browser-2026-11-15'
campaign = read(directory/'campaign.json')
summary = read(directory/'summary.json')
assert summary['passed'] and summary['cases'] == campaign['repetitions'] * len(campaign['modes'])
versions = set()
for index in range(1, campaign['repetitions'] + 1):
    for mode in campaign['modes']:
        case = directory/f'{index}-{mode}'
        report = read(case/'report.json')
        assert report['Passed'] and report['DispatcherShutdownFinished'] and report['CleanupPolicyClosed']
        data = report['Result']
        assert data['Cycles'] == campaign['retentionCycles'] and data['Warmups'] == 4
        assert data['NegativeControlDetectedAndReleased'] and not data['ReleaseGate']
        samples = data['Samples']
        assert len(samples) == data['Cycles']
        assert data['Mode'] == mode
        assert [s['Cycle'] for s in samples] == list(range(data['Cycles']))
        assert [s['Warmup'] for s in samples] == [i < 4 for i in range(data['Cycles'])]
        assert data['ReportingRetention']['VerifiedCollectedSamples'] == len(samples)
        assert data['ReportingRetention']['SampleSurvivors'] == 0
        raw = [read(p) for p in sorted((case/'bounded-samples').glob('*.json'))]
        assert raw == samples
        for s in samples:
            assert read(case/f"retention-{s['Cycle']}.json") == s
            e = s['Evidence']
            assert not s['Survivors'] and e['AllCapturedProcessesExited'] and e['RemainingProcesses'] == 0
            assert e['ParentReleases'] == e['ChildReleases'] == 1
            versions.add(e['Runtime'])
        measured = [s for s in samples if not s['Warmup']]
        assert len(measured) == data['Cycles'] - data['Warmups']
        raw_counts.append(dict(case=case.name, matched=len(raw), legacyMatched=len(samples)))
        results.append(dict(case=case.name, kind=mode, measured=len(measured), cycles=len(samples),
            metrics={k: stats([s['Collected'][k] for s in measured]) for k in
                ('ManagedBytes','HandleCount','PrivateMemorySize64','WorkingSet64','GdiObjects','UserObjects')}))
assert len(versions) == 1, versions

for name in native_names + ['fw018-long-browser-2026-11-15']:
    manifest = read(root/'artifacts'/name/'source-manifest.json')
    library_hashes.append({r['path'].replace('\\','/'): r['sha256'] for r in manifest
                          if r['path'].replace('\\','/').startswith(('UI Framework/','UI Framework.Wpf/'))})
assert library_hashes and library_hashes[0] and all(h == library_hashes[0] for h in library_hashes)
output = dict(releaseGate=False, budgetApproved=False, ownershipPassed=True,
    unchangedFrameworkSourceHashes=True, browserRuntimes=sorted(versions),
    rawSampleChecks=raw_counts, runs=results,
    limitation='Local diagnostic observations, not matched latency or hosted gate evidence. Input-monitored and earlier campaigns remain distinct; browser native HWND input is not monitored.')
path = root/'artifacts/fw018-long-summary-2026-11-15.json'
with path.open('x', encoding='utf-8') as stream:
    json.dump(output, stream, indent=2)
    stream.write('\n')
print('Validated', len(results), 'runs and', sum(c['matched'] for c in raw_counts), 'spooled samples. No memory budget approved.')
