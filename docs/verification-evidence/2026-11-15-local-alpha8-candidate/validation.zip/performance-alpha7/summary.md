# Paired rendering performance

Baseline: c5d639bcff707ff1a75b23f2a60135d6be6cb7b2. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,484.43 | 3,434.87 | -1.42% | within budget |
| full-list | Milliseconds | 2,970.58 | 2,947.18 | -0.79% | within budget |
| full-list | MountAllocatedBytes | 333,050,944.00 | 332,920,512.00 | -0.04% | within budget |
| full-list | AllocatedBytes | 467,208,672.00 | 467,212,112.00 | 0.00% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 377.58 | 368.88 | -2.30% | within budget |
| virtualized | Milliseconds | 375.04 | 371.77 | -0.87% | within budget |
| virtualized | MountAllocatedBytes | 9,538,152.00 | 9,537,544.00 | -0.01% | within budget |
| virtualized | AllocatedBytes | 47,859,240.00 | 47,859,280.00 | 0.00% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 165.00 | 165.00 | 0.00% | within budget |
| virtualized | Mounts | 69.00 | 69.00 | 0.00% | within budget |
| virtualized | Unmounts | 66.00 | 66.00 | 0.00% | within budget |
| themed-full-list | MountMilliseconds | 3,462.25 | 3,449.76 | -0.36% | within budget |
| themed-full-list | Milliseconds | 3,379.28 | 3,378.70 | -0.02% | within budget |
| themed-full-list | MountAllocatedBytes | 328,461,552.00 | 328,361,400.00 | -0.03% | within budget |
| themed-full-list | AllocatedBytes | 471,859,728.00 | 471,704,928.00 | -0.03% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,661.85 | 1,652.51 | -0.56% | within budget |
| layout-editors | Milliseconds | 7,611.47 | 7,481.12 | -1.71% | within budget |
| layout-editors | MountAllocatedBytes | 120,770,136.00 | 120,768,696.00 | -0.00% | within budget |
| layout-editors | AllocatedBytes | 1,123,300,328.00 | 1,123,297,664.00 | -0.00% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
