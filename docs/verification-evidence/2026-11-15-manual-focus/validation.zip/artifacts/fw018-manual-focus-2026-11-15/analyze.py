from pathlib import Path
import json,statistics,importlib.util,sys
sys.dont_write_bytecode=True
root=Path('artifacts/fw018-manual-focus-2026-11-15')
spec=importlib.util.spec_from_file_location('native','tools/Summarize-NativeMemory.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
r=json.loads((root/'manual.json').read_text());samples=native.validate(r,dict(rows=500,cycles=4,warmups=3,batches=600,reportingProtocol='bounded-sample-files-v1',inputObservation='window-routed-input-v1'))
raw=[json.loads(p.read_text()) for p in sorted((root/'manual.json.samples').glob('*.json'))];assert raw==r['Result']['Samples'] and len(raw)==603
assert r['Result']['FocusAtBatch']==-1 and not r['AutomationWarmup']
transitions=[]
for a,b in zip(raw,raw[1:]):
 if any(a[k]!=b[k] for k in ('GdiObjects','UserObjects')) or a['Input']['Activations']!=b['Input']['Activations']:
  transitions.append({k:b[k] for k in ('Batch','HandleCount','GdiObjects','UserObjects','CollectedManagedBytes','Input')})
metrics={}
for key in native.METRICS+('BatchMilliseconds','UiAllocatedBytes'):
 values=[s[key] for s in samples]
 metrics[key]=dict(first=values[0],last=values[-1],change=values[-1]-values[0],minimum=min(values),maximum=max(values),quarterMedians=[statistics.median(values[i:i+150]) for i in range(0,600,150)],last100Min=min(values[-100:]),last100Max=max(values[-100:]))
control=json.loads(Path('artifacts/fw018-automation-roots-2026-11-15/focus-control-1.json').read_text());assert control['Passed']
c=control['Result']['Samples'];summary=dict(releaseGate=False,memoryBudgetApproved=False,rawSamplesValidated=603,workspaceCycles=2412,nativeMounts=raw[-1]['Created'],metrics=metrics,transitions=transitions,input=native.input_summary(samples),afterShutdown=r['AfterDispatcherShutdown'],referenceControl=dict(samples=len(c),initial={k:c[3][k] for k in native.METRICS},final={k:c[-1][k] for k in native.METRICS},input=c[-1]['Input'],afterShutdown=control['AfterDispatcherShutdown']),limitations='User confirmed two clicks; the first activation precedes the prompt and includes client-area input. The same-binary reference is shorter, so this is an event attribution observation, not a matched timing benchmark.')
(root/'analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:metrics[k] for k in ('CollectedManagedBytes','HandleCount','GdiObjects','UserObjects')},indent=2));print('transitions',[(t['Batch'],t['GdiObjects'],t['UserObjects'],t['HandleCount'],t['Input']['Activations']) for t in transitions]);print('shutdown',summary['afterShutdown']);print('reference shutdown',summary['referenceControl']['afterShutdown'])
