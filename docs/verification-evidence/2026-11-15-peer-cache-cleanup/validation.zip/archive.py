from pathlib import Path
import hashlib, json, zipfile

root = Path('artifacts/fw018-peer-cache-2026-11-15')
dest = Path('docs/verification-evidence/2026-11-15-peer-cache-cleanup')
dest.mkdir(parents=True, exist_ok=True)
sources = [Path('UI Framework.Wpf/Virtualization/VirtualRowAutomationPeer.cs'),
           Path('UI Framework.Wpf/Virtualization/VirtualRowPresenter.cs'),
           Path('tests/UI Framework.Checks/AutomationLifetimeTests.cs'),
           Path('samples/NativeLifetime/AutomationRetentionProbe.cs')]
with zipfile.ZipFile(root/'changed-sources.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    for p in sources:
        z.write(p, p.as_posix())
(root/'changed-source-manifest.json').write_text(json.dumps([
    dict(path=p.as_posix(), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources
], indent=2)+'\n')
candidate = root/'performance-final-head/candidate-source'
with zipfile.ZipFile(root/'measured-candidate-sources.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(candidate.rglob('*')):
        if p.is_file(): z.write(p, p.relative_to(candidate).as_posix())
entries = []
files = [p for p in root.iterdir() if p.is_file()]
files += list((root/'tests').glob('*.trx'))
for run in ['performance-before-after', 'performance-final-head']:
    files += [p for p in (root/run).iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.md')]
with zipfile.ZipFile(dest/'validation.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):
        data=p.read_bytes(); name=p.relative_to(root).as_posix()
        z.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(dest/'validation.zip') as z:
    for e in entries:
        data=z.read(e['path'])
        assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
(dest/'manifest.json').write_text(json.dumps(dict(entries=entries,
    archiveSha256=hashlib.sha256((dest/'validation.zip').read_bytes()).hexdigest()),indent=2)+'\n')
print('Verified',len(entries),'archive entries')
