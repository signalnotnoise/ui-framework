# Paired rendering performance

Baseline: c5d639bcff707ff1a75b23f2a60135d6be6cb7b2. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,615.46 | 3,693.81 | 2.17% | within budget |
| full-list | Milliseconds | 3,295.64 | 3,226.28 | -2.10% | within budget |
| full-list | MountAllocatedBytes | 332,978,872.00 | 332,980,064.00 | 0.00% | within budget |
| full-list | AllocatedBytes | 466,827,776.00 | 467,020,272.00 | 0.04% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 387.92 | 406.98 | 4.91% | within budget |
| virtualized | Milliseconds | 402.90 | 399.88 | -0.75% | within budget |
| virtualized | MountAllocatedBytes | 9,539,056.00 | 9,538,416.00 | -0.01% | within budget |
| virtualized | AllocatedBytes | 47,884,232.00 | 47,885,312.00 | 0.00% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 165.00 | 165.00 | 0.00% | within budget |
| virtualized | Mounts | 69.00 | 69.00 | 0.00% | within budget |
| virtualized | Unmounts | 66.00 | 66.00 | 0.00% | within budget |
| themed-full-list | MountMilliseconds | 3,754.73 | 3,742.04 | -0.34% | within budget |
| themed-full-list | Milliseconds | 3,978.06 | 3,827.33 | -3.79% | within budget |
| themed-full-list | MountAllocatedBytes | 328,267,248.00 | 328,155,264.00 | -0.03% | within budget |
| themed-full-list | AllocatedBytes | 471,126,768.00 | 471,207,696.00 | 0.02% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,688.43 | 1,722.86 | 2.04% | within budget |
| layout-editors | Milliseconds | 7,855.98 | 8,050.56 | 2.48% | within budget |
| layout-editors | MountAllocatedBytes | 120,773,600.00 | 120,775,456.00 | 0.00% | within budget |
| layout-editors | AllocatedBytes | 1,123,294,040.00 | 1,123,294,200.00 | 0.00% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
