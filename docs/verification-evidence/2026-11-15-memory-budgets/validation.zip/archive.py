from pathlib import Path
import hashlib, json, zipfile

root=Path('artifacts/fw018-memory-budgets-2026-11-15')
dest=Path('docs/verification-evidence/2026-11-15-memory-budgets')
dest.mkdir(parents=True,exist_ok=True)
sources=[]
for folder in ('UI Framework','UI Framework.Wpf','samples/NativeLifetime','samples/WebViewAcceptance','samples/MeasurementTools'):
    sources += [p for p in Path(folder).rglob('*') if p.is_file() and p.suffix in ('.cs','.csproj','.html') and not {'bin','obj'} & set(p.parts)]
sources += [Path(p) for p in ('tools/memory-budgets.json','tools/Test-MemoryBudgets.py','tools/Test-MemoryBudgets.ps1',
    'tools/Test-NativeLifetime.ps1','tools/Test-WebViewAcceptance.ps1','tools/Summarize-NativeMemory.py','scripts/test-memory-budgets.py')]
with zipfile.ZipFile(root/'measured-sources.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sources:z.write(p,p.as_posix())
(root/'final-source-manifest.json').write_text(json.dumps([dict(path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources],indent=2)+'\n')
files=[p for p in root.iterdir() if p.is_file()]
for rows in (500,5000):
    folder=root/f'native-{rows}'
    files += [p for p in folder.iterdir() if p.is_file()]
    for samples in folder.glob('*.samples'):
        files += list(samples.glob('*.json'))
folder=root/'browser'
files += [p for p in folder.iterdir() if p.is_file()]
for case in folder.iterdir():
    if not case.is_dir():continue
    files += [p for p in case.iterdir() if p.is_file() and (p.name=='report.json' or p.name.startswith('retention-'))]
    files += list((case/'bounded-samples').glob('*.json'))
entries=[]
with zipfile.ZipFile(dest/'validation.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):
        data=p.read_bytes(); name=p.relative_to(root).as_posix(); z.writestr(name,data)
        entries.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(dest/'validation.zip') as z:
    for e in entries:
        data=z.read(e['path']); assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
(dest/'manifest.json').write_text(json.dumps(dict(entries=entries,archiveSha256=hashlib.sha256((dest/'validation.zip').read_bytes()).hexdigest()),indent=2)+'\n')
print('Verified',len(entries),'entries; browser profiles excluded')
