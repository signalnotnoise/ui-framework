using System.Windows.Interop;

namespace StressLab;

// Experimental intervention, not a framework policy or release default.
internal static class ComparisonPresentationProbe
{
    internal static void Prime()
    {
        using var source = new HwndSource(new HwndSourceParameters("DPI cache diagnostic")
        {
            Width = 1, Height = 1, PositionX = -10000, PositionY = -10000,
            WindowStyle = unchecked((int)0x88000000)
        });
    }
}
