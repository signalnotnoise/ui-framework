using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Text.Json;
using UI_Framework;
using UI_Framework.Wpf;
internal static class Program
{
 [STAThread] static void Main()
 {
  foreach(var count in new[]{1,100,1000})
  {
   var root = new StackPanel();
   var before=GC.GetAllocatedBytesForCurrentThread();
   ThemeStyles.Apply(root,new ThemeTokens());
   var setup=GC.GetAllocatedBytesForCurrentThread()-before;
   before=GC.GetAllocatedBytesForCurrentThread();
   var controls=Enumerable.Range(0,count).Select(i=>new TextBox {Text="Editor "+i}).ToArray();
   foreach(var control in controls)root.Children.Add(control);
   root.Measure(new Size(800,100000));root.Arrange(new Rect(0,0,800,100000));root.UpdateLayout();
   var mount=GC.GetAllocatedBytesForCurrentThread()-before;
   var brushes=controls.Select(c=>c.Background).ToArray();
   Console.WriteLine(JsonSerializer.Serialize(new {count,setup,mount,
    uniqueBackgroundBrushes=brushes.Distinct(ReferenceEqualityComparer.Instance).Count(),
    boundBackgroundBrushes=brushes.Count(b=>BindingOperations.IsDataBound(b,SolidColorBrush.ColorProperty)),
    frozenBackgroundBrushes=brushes.Count(b=>b.IsFrozen)}));
  }
 }
}
