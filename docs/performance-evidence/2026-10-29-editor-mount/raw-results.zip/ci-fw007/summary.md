# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 6,033.27 | 6,120.02 | 1.44% | within budget |
| full-list | Milliseconds | 6,587.89 | 4,995.18 | -24.18% | within budget |
| full-list | MountAllocatedBytes | 335,938,408.00 | 332,706,360.00 | -0.96% | within budget |
| full-list | AllocatedBytes | 619,744,584.00 | 464,863,632.00 | -24.99% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 437.12 | 448.17 | 2.53% | within budget |
| virtualized | Milliseconds | 1,309.42 | 724.39 | -44.68% | within budget |
| virtualized | MountAllocatedBytes | 9,676,640.00 | 9,515,544.00 | -1.66% | within budget |
| virtualized | AllocatedBytes | 63,165,376.00 | 47,849,048.00 | -24.25% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 6,527.06 | 6,104.62 | -6.47% | within budget |
| themed-full-list | Milliseconds | 12,403.18 | 5,619.01 | -54.70% | within budget |
| themed-full-list | MountAllocatedBytes | 327,165,096.00 | 327,368,424.00 | 0.06% | within budget |
| themed-full-list | AllocatedBytes | 1,064,401,480.00 | 469,205,912.00 | -55.92% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 3,290.98 | 3,284.21 | -0.21% | within budget |
| layout-editors | Milliseconds | 16,469.87 | 15,646.89 | -5.00% | within budget |
| layout-editors | MountAllocatedBytes | 126,187,096.00 | 121,448,472.00 | -3.76% | within budget |
| layout-editors | AllocatedBytes | 1,156,380,192.00 | 1,113,024,064.00 | -3.75% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
