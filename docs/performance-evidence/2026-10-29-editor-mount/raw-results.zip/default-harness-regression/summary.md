# Paired rendering performance

Baseline: 5fd4a2a1de9423baba0639d55f8b192d7e5dbff3. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| layout-editors | MountMilliseconds | 2,540.56 | 1,950.03 | -23.24% | within budget |
| layout-editors | Milliseconds | 21,504.04 | 21,109.11 | -1.84% | within budget |
| layout-editors | MountAllocatedBytes | 121,490,000.00 | 121,495,832.00 | 0.00% | within budget |
| layout-editors | AllocatedBytes | 1,112,719,952.00 | 1,112,986,568.00 | 0.02% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
