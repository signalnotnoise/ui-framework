using System.Windows;
using System.Windows.Controls;
using UI_Framework;

namespace UI_Framework.Wpf;

internal sealed class IconButtonContent : DockPanel
{
    private const double LabelSpacing = 6;
    private readonly IconElement icon = new() { Decorative = true, VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock label = new() { TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center };

    internal IconButtonContent()
    {
        IsHitTestVisible = false;
        SetDock(icon, Dock.Left);
        Children.Add(icon);
        Children.Add(label);
    }

    internal static void Patch(Button button, View view)
    {
        if (view.Icon is null)
        {
            button.Content = view.Content;
            button.ClearValue(ToolTipProperty);
            return;
        }
        var content = button.Content as IconButtonContent;
        if (content is null) button.Content = content = new IconButtonContent();
        content.icon.Update(view.Icon, view.TextSize);
        var hasLabel = !string.IsNullOrEmpty(view.Content);
        var margin = new Thickness(0, 0, hasLabel ? LabelSpacing : 0, 0);
        if (content.icon.Margin != margin) content.icon.Margin = margin;
        if (content.label.Text != view.Content) content.label.Text = view.Content;
        var visibility = hasLabel ? Visibility.Visible : Visibility.Collapsed;
        if (content.label.Visibility != visibility) content.label.Visibility = visibility;
        var tooltip = hasLabel ? null : view.AccessibleName;
        if (!Equals(button.ToolTip, tooltip)) button.ToolTip = tooltip;
    }
}
