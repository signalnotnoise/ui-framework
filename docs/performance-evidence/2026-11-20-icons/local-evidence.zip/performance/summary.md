# Paired rendering performance

Baseline: 04ce2e9a0ab2eab9f26137aaa8e2b103ccfe7554. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,759.15 | 3,761.22 | 0.05% | within budget |
| full-list | Milliseconds | 3,330.53 | 3,325.62 | -0.15% | within budget |
| full-list | MountAllocatedBytes | 333,277,504.00 | 333,572,832.00 | 0.09% | within budget |
| full-list | AllocatedBytes | 468,016,440.00 | 469,602,640.00 | 0.34% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 407.60 | 403.46 | -1.02% | within budget |
| virtualized | Milliseconds | 393.16 | 392.33 | -0.21% | within budget |
| virtualized | MountAllocatedBytes | 9,567,368.00 | 9,595,568.00 | 0.29% | within budget |
| virtualized | AllocatedBytes | 48,386,104.00 | 48,888,744.00 | 1.04% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 165.00 | 165.00 | 0.00% | within budget |
| virtualized | Mounts | 69.00 | 69.00 | 0.00% | within budget |
| virtualized | Unmounts | 66.00 | 66.00 | 0.00% | within budget |
| themed-full-list | MountMilliseconds | 3,812.86 | 3,782.55 | -0.79% | within budget |
| themed-full-list | Milliseconds | 3,692.30 | 3,639.29 | -1.44% | within budget |
| themed-full-list | MountAllocatedBytes | 328,244,992.00 | 329,045,712.00 | 0.24% | within budget |
| themed-full-list | AllocatedBytes | 473,188,872.00 | 473,678,952.00 | 0.10% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
