using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using UI_Framework;
using UI_Framework.Wpf;
using static UI_Framework.UI;

internal static class Program
{
    private const double HeadingSize = 24, IconSize = 24, SectionGap = 16, ItemGap = 12, PagePadding = 24;
    private const double WideWidth = 600, NarrowWidth = 340, PageHeight = 390, Dpi = 144, OutlineWidth = 2;
    private static readonly VectorIcon Add = new("M 12,4 V 20 M 4,12 H 20", strokeWidth: OutlineWidth);
    private static readonly VectorIcon Check = new("M 4,12 L 9,17 L 20,6", strokeWidth: OutlineWidth);
    private static readonly VectorIcon Box = new("M 4,4 H 20 V 20 H 4 Z");
    private static void Click() { }
    [STAThread]
    private static void Main()
    {
        var light = new ThemeTokens();
        var dark = new ThemeTokens { Canvas = "#181C22", Surface = "#222832", Ink = "#E8EDF4", Muted = "#9BA7B8", Border = "#3A4555", Hover = "#303A48", Pressed = "#3B485A", Accent = "#568FEA", OnAccent = "#101821" };
        foreach (var (name, theme) in new[] { ("light", light), ("dark", dark) })
        foreach (var width in new[] { WideWidth, NarrowWidth })
        {
            using var host = new ViewHost(() => VStack(
                Text("Vector icons").FontSize(HeadingSize),
                Text("Native buttons, shared paths and theme colors"),
                HStack(Icon(Add, IconSize), Icon(Check, IconSize), Icon(Box, IconSize)).Spacing(ItemGap),
                HStack(Button(Add, "Add item", Click).ButtonStyle(ButtonStyleKind.Primary), IconButton(Check, "Confirm", Click)).Spacing(ItemGap),
                Button(Check, "Save all changes in this workspace", Click),
                HStack(IconButton(Add, "Add", Click).ButtonStyle(ButtonStyleKind.Quiet), Button(Check, "Saved", Click).IsEnabled(false)).Spacing(ItemGap)
            ).Spacing(SectionGap).Padding(PagePadding).Foreground(theme.Ink).Background(theme.Canvas));
            ThemeStyles.Apply(host, theme);
            host.Measure(new Size(width, PageHeight)); host.Arrange(new Rect(0, 0, width, PageHeight)); host.UpdateLayout();
            var bitmap = new RenderTargetBitmap((int)(width * Dpi / 96), (int)(PageHeight * Dpi / 96), Dpi, Dpi, PixelFormats.Pbgra32);
            bitmap.Render(host);
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var output = File.Create($"artifacts/icons/{name}-{width}.png"); encoder.Save(output);
        }
    }
}
