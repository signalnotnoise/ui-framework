# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 5,866.92 | 5,910.35 | 0.74% | within budget |
| full-list | Milliseconds | 5,926.10 | 4,610.04 | -22.21% | within budget |
| full-list | MountAllocatedBytes | 336,086,656.00 | 332,649,784.00 | -1.02% | within budget |
| full-list | AllocatedBytes | 619,601,928.00 | 464,877,648.00 | -24.97% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 417.34 | 421.12 | 0.91% | within budget |
| virtualized | Milliseconds | 1,403.40 | 667.38 | -52.45% | within budget |
| virtualized | MountAllocatedBytes | 9,664,304.00 | 9,515,544.00 | -1.54% | within budget |
| virtualized | AllocatedBytes | 63,165,376.00 | 47,849,048.00 | -24.25% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 5,760.05 | 5,896.04 | 2.36% | within budget |
| themed-full-list | Milliseconds | 11,606.79 | 5,280.59 | -54.50% | within budget |
| themed-full-list | MountAllocatedBytes | 327,400,264.00 | 327,524,224.00 | 0.04% | within budget |
| themed-full-list | AllocatedBytes | 1,064,413,288.00 | 469,207,888.00 | -55.92% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 3,069.25 | 3,148.89 | 2.59% | within budget |
| layout-editors | Milliseconds | 15,502.46 | 15,340.11 | -1.05% | within budget |
| layout-editors | MountAllocatedBytes | 125,470,136.00 | 120,756,768.00 | -3.76% | within budget |
| layout-editors | AllocatedBytes | 1,156,411,584.00 | 1,112,653,400.00 | -3.78% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
