namespace UI_Framework.Wpf;

internal sealed class VirtualRow(View view)
{
    // Intrusive AVL metadata: zero height means detached; collection owns all links.
    internal VirtualRow? Left, Right, Parent;
    internal int Height, Count;
    internal View View = view;
    // Desired position for retained rows; old position for rows being removed.
    internal int TargetIndex;
    internal NodeSnapshot? Saved;
    internal VirtualRowPresenter? Presenter;
    internal RowFocusSnapshot? Focus;
}
