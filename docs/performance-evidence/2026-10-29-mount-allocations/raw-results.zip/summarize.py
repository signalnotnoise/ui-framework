from pathlib import Path
import json,statistics
p=Path('artifacts/fw007-mount-2026-10-29')
for name in ['accepted-layout-guard','accepted-layout-phase1','accepted-refresh-phase1']:
 f=p/name/'comparison.json'
 if not f.exists():continue
 d=json.loads(f.read_text(encoding='utf-8-sig')); print(name)
 for count,scenario in sorted({(x['count'],x['scenario']) for x in d['results']}):
  groups=[[x for x in d['results'] if x['count']==count and x['scenario']==scenario and x['side']==side and not x['warmup']] for side in ['baseline','candidate']]
  metrics=['milliseconds','mountMilliseconds','mountAllocated','allocated','builds','mounts','unmounts','nativeEditors']
  print(count,scenario,[{k:statistics.median(x[k] for x in g) for k in metrics if k in g[0]} for g in groups])
f=p/'performance/summary.json'
if f.exists():
 d=json.loads(f.read_text(encoding='utf-8-sig'));print('Broad passed:',d['passed']);print('Failing:',[(x['scenario'],x['metric'],x['changePercent']) for x in d['comparisons'] if x['regression']])
 for x in d['comparisons']:print(x['scenario'],x['metric'],x['baselineMedian'],x['candidateMedian'],x['changePercent'])
