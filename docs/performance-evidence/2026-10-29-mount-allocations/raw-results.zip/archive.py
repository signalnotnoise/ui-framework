from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();src=root/'artifacts/fw007-mount-2026-10-29';out=root/'docs/performance-evidence/2026-10-29-mount-allocations'
out.mkdir(exist_ok=False)
entries=[]
def pack(name,files,base):
 with zipfile.ZipFile(out/name,'x',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(files):
   b=f.read_bytes();rel=f.relative_to(base).as_posix();z.writestr(rel,b)
   entries.append(dict(archive=name,path=rel,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
exclude={'guard','phase1','baseline','baseline-source','candidate','candidate-source','bin','obj'}
pack('raw-results.zip',[f for f in src.rglob('*') if f.is_file() and not any(x in exclude for x in f.relative_to(src).parts) and f.suffix in {'.json','.log','.trx','.py','.cs','.ps1'}],src)
files=[]
for folder in ['UI Framework','UI Framework.Wpf','tests/UI Framework.Checks','samples/Counter','tools/KeyedShuffleDiagnostics']:
 files += [f for f in (root/folder).rglob('*') if f.is_file() and not any(x in {'bin','obj'} for x in f.relative_to(root/folder).parts)]
files += [root/f for f in ['Directory.Build.props','global.json','tools/Test-KeyedShuffles.ps1','tools/Test-Performance.ps1','tools/performance-baseline.json']]
pack('candidate-source.zip',files,root)
for name in ['intrusive-probe','layout-phase1','final-layout-phase1','insert-batch-probe']:
 base=src/name/'candidate-source'
 pack(name+'-source.zip',[f for f in base.rglob('*') if f.is_file() and not any(x in {'bin','obj'} for x in f.relative_to(base).parts)],base)
base=src/'phase-diagnostic'
pack('phase-diagnostic-source.zip',[f for f in base.rglob('*') if f.is_file() and any(x in {'baseline','candidate'} for x in f.relative_to(base).parts) and not any(x in {'bin','obj'} for x in f.relative_to(base).parts)],base)
(out/'manifest.json').write_text(json.dumps({'date':'2026-10-29','baseline':'Broad: alpha.6 62db456. Supplemental: phase-one snapshot in ../2026-10-28-indexed-shuffles/phase1-source.zip and guarded snapshot in ../2026-10-28-guarded-move/candidate-source.zip. Accepted baseline and budgets unchanged.','entries':entries},indent=2)+'\n',encoding='utf-8',newline='\n')
for name in {x['archive'] for x in entries}:
 with zipfile.ZipFile(out/name) as z:
  for x in entries:
   if x['archive']==name: assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
print(len(entries),'archived entries; hashes verified')
