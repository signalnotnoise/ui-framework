namespace UI_Framework.Wpf;

internal sealed class VirtualRow(View view)
{
    internal View View = view;
    internal int TargetIndex;
    internal int RemovalIndex;
    internal NodeSnapshot? Saved;
    internal VirtualRowPresenter? Presenter;
    internal RowFocusSnapshot? Focus;
}
