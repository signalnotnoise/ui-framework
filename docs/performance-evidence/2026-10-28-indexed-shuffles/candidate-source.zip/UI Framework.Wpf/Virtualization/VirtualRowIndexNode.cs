namespace UI_Framework.Wpf;

internal sealed class VirtualRowIndexNode(VirtualRow row)
{
    internal readonly VirtualRow Row = row;
    internal VirtualRowIndexNode? Left, Right, Parent;
    internal int Height = 1;
    internal int Count = 1;
}
