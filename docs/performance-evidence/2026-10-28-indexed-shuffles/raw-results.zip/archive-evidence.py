from pathlib import Path
import json, zipfile, hashlib
root=Path.cwd(); src=root/'artifacts/fw007-arbitrary'; out=root/'docs/performance-evidence/2026-10-28-indexed-shuffles'
out.mkdir(exist_ok=False)
entries=[]
def archive(name, files, base):
 with zipfile.ZipFile(out/name,'x',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(files):
   data=f.read_bytes(); rel=f.relative_to(base).as_posix(); z.writestr(rel,data)
   entries.append(dict(archive=name,path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
exclude={'baseline','baseline-source','candidate-source','phase1-source','phase1-retention-check','bin','obj'}
files=[f for f in src.rglob('*') if f.is_file() and not any(x in exclude for x in f.relative_to(src).parts) and f.suffix in {'.json','.log','.trx','.jsonl','.nettrace','.py'}]
archive('raw-results.zip',files,src)
files=[]
for folder in ['UI Framework','UI Framework.Wpf','tests/UI Framework.Checks','samples/Counter','tools/KeyedShuffleDiagnostics']:
 files += [f for f in (root/folder).rglob('*') if f.is_file() and not any(x in {'bin','obj'} for x in f.relative_to(root/folder).parts)]
files += [root/f for f in ['Directory.Build.props','global.json','tools/Test-KeyedShuffles.ps1','tools/Test-Performance.ps1','tools/performance-baseline.json']]
archive('candidate-source.zip',files,root)
archive('phase1-source.zip',[f for f in (src/'phase1-source').rglob('*') if f.is_file() and not any(x in {'bin','obj'} for x in f.relative_to(src/'phase1-source').parts)],src/'phase1-source')
manifest={'date':'2026-10-28','scope':'FW-007 local validation; includes failed/intermediate evidence. Broad comparison is against alpha.6 (62db456), supplemental indexed comparisons use the preserved phase-one source. No baseline promotion or release.','entries':entries}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(len(entries),'archived files')
