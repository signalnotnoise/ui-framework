import json, pathlib, statistics
p=pathlib.Path('artifacts/fw007-arbitrary')
for name in ['cursor-paired','cursor-layout','cursor-full-layout']:
 f=p/name/'comparison.json'
 if not f.exists(): continue
 d=json.loads(f.read_text(encoding='utf-8-sig')); rows=d['results']; print(name)
 for count,scenario in sorted({(x['count'],x['scenario']) for x in rows}):
  groups=[[x for x in rows if x['count']==count and x['scenario']==scenario and x['side']==side and not x['warmup']] for side in ['baseline','candidate']]
  a,b=[statistics.median(x['milliseconds'] for x in group) for group in groups]
  print(count,scenario,round(a,3),round(b,3),round((b/a-1)*100,2))
