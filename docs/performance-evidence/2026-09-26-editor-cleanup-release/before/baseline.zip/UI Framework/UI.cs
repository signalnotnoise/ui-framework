namespace UI_Framework;

public static class UI
{
    /// <summary>Displays the top history entry and retains logical state for entries below it.</summary>
    public static View Navigation<TRoute>(NavigationStack<TRoute> history, Func<TRoute, View> screen,
        NavigationTransition transition = NavigationTransition.FadeSlide) where TRoute : notnull
    {
        ArgumentNullException.ThrowIfNull(history);
        ArgumentNullException.ThrowIfNull(screen);
        return new(ViewKind.Navigation)
        {
            Children = history.Entries.Select(entry => screen(entry.Route).Id(entry.Id.ToString(System.Globalization.CultureInfo.InvariantCulture))).ToArray(),
            Transition = transition
        };
    }
    /// <summary>Distributes finite horizontal space by Flex weight. Explicit Width takes precedence.</summary>
    public static View FlexRow(params View[] children) => new(ViewKind.FlexRow) { Children = children };
    /// <summary>Distributes finite vertical space by Flex weight. Explicit Height takes precedence.</summary>
    public static View FlexColumn(params View[] children) => new(ViewKind.FlexColumn) { Children = children };
    /// <summary>Content-sized edge regions around a center that fills the remaining finite space.</summary>
    public static View Dock(View center, View? top = null, View? bottom = null, View? left = null, View? right = null)
    {
        ArgumentNullException.ThrowIfNull(center);
        List<View> middle = [];
        if (left is not null) middle.Add(FlexColumn(left).Flex(0).Id("left"));
        middle.Add(FlexColumn(center).Id("center"));
        if (right is not null) middle.Add(FlexColumn(right).Flex(0).Id("right"));
        List<View> rows = [];
        if (top is not null) rows.Add(FlexColumn(top).Flex(0).Id("top"));
        rows.Add(FlexRow(middle.ToArray()).Id("middle"));
        if (bottom is not null) rows.Add(FlexColumn(bottom).Flex(0).Id("bottom"));
        return FlexColumn(rows.ToArray());
    }
    /// <summary>Two retained panes with a bound first-pane size, native mouse/keyboard resizing and optional collapse.</summary>
    public static View SplitPane(View first, View second, State<double> firstExtent,
        SplitAxis axis = SplitAxis.Horizontal, double minimumFirst = 100, double minimumSecond = 100, bool firstCollapsed = false)
        => SplitPane(first, second, firstExtent.Binding(), axis, minimumFirst, minimumSecond, firstCollapsed);
    public static View SplitPane(View first, View second, Binding<double> firstExtent,
        SplitAxis axis = SplitAxis.Horizontal, double minimumFirst = 100, double minimumSecond = 100, bool firstCollapsed = false)
    {
        ArgumentNullException.ThrowIfNull(first); ArgumentNullException.ThrowIfNull(second); ArgumentNullException.ThrowIfNull(firstExtent);
        return new(ViewKind.SplitPane) { Children = [first, second],
            SplitLayout = new(firstExtent.Value, value => firstExtent.Value = value, () => firstExtent.Value,
                axis, minimumFirst, minimumSecond, firstCollapsed) };
    }
    /// <summary>Equal-width columns that wrap as available width changes.</summary>
    public static View AdaptiveGrid(double minimumColumnWidth, params View[] children) =>
        double.IsFinite(minimumColumnWidth) && minimumColumnWidth > 0
            ? new(ViewKind.AdaptiveGrid) { Children = children, MinimumColumnWidth = minimumColumnWidth }
            : throw new ArgumentOutOfRangeException(nameof(minimumColumnWidth));
    // Factories are invoked only when a component is first mounted or its identity changes.
    public static View Component<T>(Action<T>? configure = null) where T : Component, new() =>
        new(ViewKind.Component)
        {
            ComponentType = typeof(T),
            CreateComponent = static () => new T(),
            ConfigureComponent = configure is null ? null : component => configure((T)component)
        };
    public static View Text(string text) => new(ViewKind.Text) { Content = text };
    public static View Button(string text, Action click) => new(ViewKind.Button) { Content = text, Click = click };
    public static View TextField(State<string> value) => TextField(value.Binding());
    public static View TextField(Binding<string> value) => new(ViewKind.TextField)
        { Content = value.Value, Edit = text => value.Value = text, ReadText = () => value.Value };
    public static View TextEditor(State<string> value) => TextEditor(value.Binding());
    public static View TextEditor(Binding<string> value) => new(ViewKind.TextEditor)
        { Content = value.Value, Edit = text => value.Value = text, ReadText = () => value.Value };
    /// <summary>Masks input on screen; the binding still contains a managed string.</summary>
    public static View PasswordField(State<string> value) => PasswordField(value.Binding());
    public static View PasswordField(Binding<string> value) => new(ViewKind.PasswordField)
        { Content = value.Value, Edit = text => value.Value = text, ReadText = () => value.Value };
    public static View Picker(IReadOnlyList<string> options, State<int> selectedIndex) => Picker(options, selectedIndex.Binding());
    /// <summary>Indices are positional. Out-of-range values display no selection without changing the binding.</summary>
    public static View Picker(IReadOnlyList<string> options, Binding<int> selectedIndex)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(selectedIndex);
        return new(ViewKind.Picker)
        {
            Options = options.ToArray(), SelectedIndex = selectedIndex.Value,
            SelectionChanged = index => selectedIndex.Value = index, ReadSelectedIndex = () => selectedIndex.Value
        };
    }
    public static View Toggle(string label, State<bool> value) => Toggle(label, value.Binding());
    public static View Toggle(string label, Binding<bool> value) => new(ViewKind.Toggle)
        { Content = label, Checked = value.Value, ToggleChanged = next => value.Value = next, ReadChecked = () => value.Value };
    public static View Scroll(View content) => new(ViewKind.Scroll) { Children = [content] };
    /// <summary>Keyed rows with a finite viewport. Only visible rows and a scroll buffer mount.</summary>
    public static View VirtualList(IEnumerable<View> rows, double height) =>
        new View(ViewKind.VirtualList) { Children = rows.ToArray() }.Height(height);
    public static View VStack(params View[] children) => new(ViewKind.VStack) { Children = children };
    public static View HStack(params View[] children) => new(ViewKind.HStack) { Children = children };
}
