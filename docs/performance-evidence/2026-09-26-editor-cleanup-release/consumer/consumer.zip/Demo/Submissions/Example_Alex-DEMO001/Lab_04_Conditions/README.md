# Demo conditions lab

Fictitious sample. Read an integer score, reject values outside 0-100,
and print Pass for scores of 70 or above.
