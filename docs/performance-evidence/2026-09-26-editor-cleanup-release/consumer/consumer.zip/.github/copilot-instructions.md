# Copilot Instructions

## Project Guidelines
- Test with AI should launch the student program and have an LLM agent watch the live console/stream, then type input in response. Do not pre-generate batch stdin test cases and dump them into the process.