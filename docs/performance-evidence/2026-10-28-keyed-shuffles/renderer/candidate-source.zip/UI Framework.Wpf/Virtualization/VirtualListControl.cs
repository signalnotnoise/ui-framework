using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using System.Windows.Automation.Peers;

namespace UI_Framework.Wpf;

// WPF supplies variable-height measurement, pixel scrolling, viewport caching and recycling.
internal sealed class VirtualListControl : ItemsControl, IDisposable
{
    private Dictionary<string, VirtualRow> rows = [];
    private readonly ObservableCollection<VirtualRow> ordered = [];
    private double gap;
    private bool disposed;
    private IReadOnlyDictionary<string, NodeSnapshot>? initialRows;

    internal VirtualListControl(VirtualListSnapshot? snapshot = null)
    {
        initialRows = snapshot?.Rows;
        VirtualizingPanel.SetIsVirtualizing(this, true);
        VirtualizingPanel.SetVirtualizationMode(this, VirtualizationMode.Recycling);
        VirtualizingPanel.SetScrollUnit(this, ScrollUnit.Pixel);
        VirtualizingPanel.SetCacheLength(this, new VirtualizationCacheLength(0.5));
        VirtualizingPanel.SetCacheLengthUnit(this, VirtualizationCacheLengthUnit.Page);
        ScrollViewer.SetCanContentScroll(this, true);
        var panel = new FrameworkElementFactory(typeof(VirtualizingStackPanel));
        ItemsPanel = new ItemsPanelTemplate(panel);
        var scroll = new FrameworkElementFactory(typeof(ScrollViewer));
        scroll.SetValue(ScrollViewer.CanContentScrollProperty, true);
        scroll.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        scroll.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        scroll.AppendChild(new FrameworkElementFactory(typeof(ItemsPresenter)));
        Template = new ControlTemplate(typeof(ItemsControl)) { VisualTree = scroll };
        HorizontalContentAlignment = HorizontalAlignment.Stretch;
        ItemsSource = ordered;
    }

    protected override AutomationPeer OnCreateAutomationPeer() => new VirtualListAutomationPeer(this);
    protected override bool IsItemItsOwnContainerOverride(object item) => false;
    protected override DependencyObject GetContainerForItemOverride() => new VirtualRowPresenter();
    protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
    {
        // The presenter owns Content; do not let ItemsControl replace it with the data item.
        ((VirtualRowPresenter)element).Attach((VirtualRow)item, gap);
    }
    protected override void ClearContainerForItemOverride(DependencyObject element, object item) =>
        ((VirtualRowPresenter)element).Release();

    internal void Update(IReadOnlyList<View> views, double spacing)
    {
        ObjectDisposedException.ThrowIf(disposed, this);
        gap = spacing;
        var containsNewRows = false;
        var next = new VirtualRow[views.Count];
        var nextByKey = new Dictionary<string, VirtualRow>(views.Count);
        for (var i = 0; i < views.Count; i++)
        {
            var view = views[i];
            var row = rows.GetValueOrDefault(view.Key!);
            if (row is null)
            {
                containsNewRows = true;
                row = new VirtualRow(view) { Saved = initialRows?.GetValueOrDefault(view.Key!) };
            }
            row.View = view;
            next[i] = row;
            nextByKey.Add(view.Key!, row);
        }

        // Detach all removed readers before invoking any user unmount hook.
        var removed = rows.Where(pair => !nextByKey.ContainsKey(pair.Key)).Select(pair => pair.Value).ToArray();
        foreach (var row in removed) row.Presenter?.Deactivate();
        for (var i = ordered.Count - 1; i >= 0; i--)
        {
            var row = ordered[i];
            if (nextByKey.ContainsKey(row.View.Key!)) continue;
            row.Presenter?.Release();
            ordered.RemoveAt(i);
            row.Saved = null;
        }

        // Preserve the ItemsSource and retained row objects; never reset for a reorder.
        for (var i = 0; i < next.Length; i++)
        {
            var desired = next[i];
            if (i < ordered.Count && ReferenceEquals(ordered[i], desired)) continue;
            // A newly described key cannot be in the retained collection. In particular,
            // initial mount and append must not scan every previously inserted row.
            if (containsNewRows && !rows.ContainsKey(desired.View.Key!))
            {
                ordered.Insert(i, desired);
                continue;
            }
            // A single forward move leaves its successor at the destination we need
            // next. Move an unrealized displaced row once instead of all intervening rows.
            // Moving a live presenter can detach it before composition completion;
            // retain the existing path for realized rows, including focus-pinned rows.
            if (i + 1 < ordered.Count && ordered[i].Presenter is null
                && ReferenceEquals(ordered[i + 1], desired))
            {
                var destination = Array.IndexOf(next, ordered[i], i + 1);
                if (destination > i) ordered.Move(i, Math.Min(destination, ordered.Count - 1));
            }
            if (ReferenceEquals(ordered[i], desired)) continue;
            ordered.Move(ordered.IndexOf(desired), i);
        }
        rows = nextByKey;
        initialRows = null;
        foreach (var row in next) row.Presenter?.Refresh(gap);
    }

    internal void Deactivate()
    {
        foreach (var row in ordered) row.Presenter?.Deactivate();
    }

    internal VirtualListSnapshot Capture()
    {
        var snapshots = new Dictionary<string, NodeSnapshot>();
        foreach (var (key, row) in rows)
            if ((row.Presenter?.Capture() ?? row.Saved) is { } snapshot) snapshots.Add(key, snapshot);
        return new(snapshots);
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        Deactivate();
        List<Exception>? errors = null;
        foreach (var row in ordered)
        {
            try { row.Presenter?.Release(); }
            catch (Exception error) { (errors ??= []).Add(error); }
        }
        ItemsSource = null;
        rows.Clear();
        ordered.Clear();
        initialRows = null;
        if (errors is not null) throw new AggregateException("Virtual row cleanup failed.", errors);
    }
}
