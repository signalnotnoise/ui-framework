#requires -Version 7.0
param(
    [Parameter(Mandatory)][string]$BaselineRef,
    [Parameter(Mandatory)][string]$OutputDirectory,
    [ValidateRange(3,15)][int]$Samples = 7
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$output = [IO.Path]::GetFullPath($OutputDirectory, $root)
if (Test-Path -LiteralPath $output) { throw 'Use a new output directory to preserve evidence.' }
New-Item -ItemType Directory -Path $output | Out-Null
Push-Location $root
try {
    $revision = (& git rev-parse --verify "$BaselineRef^{commit}").Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Baseline must be a local commit.' }
    & git archive --format=zip "--output=$output/baseline-source.zip" $revision
    if ($LASTEXITCODE -ne 0) { throw 'Baseline archive failed.' }
    $baseline = Join-Path $output 'baseline'
    Expand-Archive -LiteralPath "$output/baseline-source.zip" -DestinationPath $baseline
    $harness = 'tools/KeyedShuffleDiagnostics'
    New-Item -ItemType Directory -Path (Join-Path $baseline $harness) -Force | Out-Null
    Copy-Item "$harness/*.cs", "$harness/*.csproj" -Destination (Join-Path $baseline $harness)
    $candidate = Join-Path $output 'candidate-source'
    foreach ($folder in @('UI Framework','UI Framework.Wpf','tools/KeyedShuffleDiagnostics')) {
        Get-ChildItem $folder -Recurse -File | Where-Object { $_.FullName -notmatch '[\\/](bin|obj)[\\/]' } | ForEach-Object {
            $relative = [IO.Path]::GetRelativePath($root, $_.FullName)
            $target = Join-Path $candidate $relative
            New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
            Copy-Item -LiteralPath $_.FullName -Destination $target
        }
    }
    Copy-Item Directory.Build.props,global.json -Destination $candidate
    foreach ($build in @($baseline,$candidate)) {
        & dotnet build (Join-Path $build "$harness/KeyedShuffleDiagnostics.csproj") -c Release --disable-build-servers -m:1 -warnaserror
        if ($LASTEXITCODE -ne 0) { throw 'Diagnostic build failed.' }
    }
    $results = @()
    foreach ($count in @(1000,10000)) {
        foreach ($scenario in @('rotate','reverse','shuffle','filter')) {
            for ($sample = 0; $sample -le $Samples; $sample++) {
                $order = if ($sample % 2 -eq 0) { @('baseline','candidate') } else { @('candidate','baseline') }
                foreach ($side in $order) {
                    $source = if ($side -eq 'baseline') { $baseline } else { $candidate }
                    $log = Join-Path $output "$count-$scenario-$sample-$side.json"
                    & dotnet (Join-Path $source "$harness/bin/Release/net10.0-windows/KeyedShuffleDiagnostics.dll") $count $scenario > $log
                    if ($LASTEXITCODE -ne 0) { throw "Diagnostic failed: $log" }
                    $result = Get-Content $log -Raw | ConvertFrom-Json
                    $result | Add-Member side $side
                    $result | Add-Member sample $sample
                    $result | Add-Member warmup ($sample -eq 0)
                    $results += $result
                }
            }
        }
    }
    [pscustomobject]@{ baseline=$revision; samples=$Samples; sdk=(& dotnet --version).Trim(); scope='Detached logical collection only, not a release gate; run Test-Performance with full-list and virtualization separately.'; results=$results } |
        ConvertTo-Json -Depth 6 | Set-Content (Join-Path $output 'comparison.json')
} finally { Pop-Location }
