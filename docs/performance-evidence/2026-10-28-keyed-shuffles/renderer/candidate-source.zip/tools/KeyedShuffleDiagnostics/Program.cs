using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Text.Json;
using System.Windows.Controls;
using UI_Framework;
using UI_Framework.Wpf;
using static UI_Framework.UI;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        var count = int.Parse(args[0]);
        var scenario = args[1];
        var ids = Enumerable.Range(0, count).ToArray();
        View[] Describe() => ids.Select(i => Text(i.ToString()).Id(i.ToString())).ToArray();
        using var host = new ViewHost(() => VirtualList(Describe(), 300));
        var control = (ItemsControl)((Border)host.Content).Child;
        var source = (IList)control.ItemsSource;
        var original = source.Cast<object>().ToArray();
        var moves = 0; var inserts = 0; var removes = 0; var resets = 0;
        ((INotifyCollectionChanged)source).CollectionChanged += (_, e) =>
        {
            if (e.Action == NotifyCollectionChangedAction.Move) moves++;
            if (e.Action == NotifyCollectionChangedAction.Add) inserts++;
            if (e.Action == NotifyCollectionChangedAction.Remove) removes++;
            if (e.Action == NotifyCollectionChangedAction.Reset) resets++;
        };
        ids = scenario switch
        {
            "rotate" => ids.Skip(1).Append(ids[0]).ToArray(),
            "reverse" => ids.Reverse().ToArray(),
            "shuffle" => ids.ToArray(),
            "filter" => ids.Where(i => i % 2 == 0).ToArray(),
            _ => throw new ArgumentException("rotate, reverse, shuffle or filter")
        };
        if (scenario == "shuffle") { var random = new Random(42); random.Shuffle(ids); }
        var allocated = GC.GetAllocatedBytesForCurrentThread();
        var clock = Stopwatch.StartNew();
        host.Refresh();
        clock.Stop();
        allocated = GC.GetAllocatedBytesForCurrentThread() - allocated;
        if (source.Count != ids.Length || ids.Where((id, index) => !ReferenceEquals(original[id], source[index])).Any())
            throw new InvalidOperationException("Row identity or order changed incorrectly.");
        Console.WriteLine(JsonSerializer.Serialize(new { count, scenario, milliseconds = clock.Elapsed.TotalMilliseconds, allocated, moves, inserts, removes, resets,
            scope = "Detached logical collection only; excludes realization/layout; not a release gate", runtime = Environment.Version.ToString() }));
    }
}
