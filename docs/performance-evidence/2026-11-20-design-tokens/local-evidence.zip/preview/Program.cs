using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using UI_Framework;
using UI_Framework.Wpf;
using static UI_Framework.UI;

internal static class Program
{
    private const double WideWidth = 600, NarrowWidth = 340, PageHeight = 390, ExpandedPageHeight = 480, Dpi = 144, OutlineWidth = 2;
    private static readonly VectorIcon Add = new("M 12,4 V 20 M 4,12 H 20", strokeWidth: OutlineWidth);
    private static readonly VectorIcon Check = new("M 4,12 L 9,17 L 20,6", strokeWidth: OutlineWidth);
    private static readonly VectorIcon Box = new("M 4,4 H 20 V 20 H 4 Z");
    private static void Click() { }
    [STAThread]
    private static void Main()
    {
        var light = new ThemeTokens();
        var dark = new ThemeTokens { Canvas = "#181C22", Surface = "#222832", Ink = "#E8EDF4", Muted = "#9BA7B8", Border = "#3A4555", Hover = "#303A48", Pressed = "#3B485A", Accent = "#568FEA", OnAccent = "#101821" };
        var enlarged = light with { Typography = light.Typography with { Body = 18, Heading = 28 }, Icons = light.Icons with { Medium = 32, LabelGap = 12 }, Spacing = light.Spacing with { Medium = 16, Large = 20, ExtraLarge = 28 } };
        foreach (var (name, theme) in new[] { ("light", light), ("dark", dark), ("enlarged", enlarged) })
        foreach (var width in new[] { WideWidth, NarrowWidth })
        {
            var height = name == "enlarged" ? ExpandedPageHeight : PageHeight;
            using var host = new ViewHost(() => VStack(
                Text("Vector icons").FontSize(theme.Typography.Heading),
                Text("Native buttons, shared paths and theme colors").FontSize(theme.Typography.Body),
                HStack(Icon(Add, theme.Icons.Medium), Icon(Check, theme.Icons.Medium), Icon(Box, theme.Icons.Medium)).Spacing(theme.Spacing.Medium),
                HStack(Button(Add, "Add item", Click).FontSize(theme.Typography.Body).ButtonStyle(ButtonStyleKind.Primary), IconButton(Check, "Confirm", Click).FontSize(theme.Icons.Small)).Spacing(theme.Spacing.Medium),
                Button(Check, "Save all changes in this workspace", Click).FontSize(theme.Typography.Body),
                HStack(IconButton(Add, "Add", Click).ButtonStyle(ButtonStyleKind.Quiet), Button(Check, "Saved", Click).IsEnabled(false)).Spacing(theme.Spacing.Medium)
            ).Spacing(theme.Spacing.Large).Padding(theme.Spacing.ExtraLarge).Foreground(theme.Ink).Background(theme.Canvas));
            ThemeStyles.Apply(host, theme);
            host.Measure(new Size(width, height)); host.Arrange(new Rect(0, 0, width, height)); host.UpdateLayout();
            var bitmap = new RenderTargetBitmap((int)(width * Dpi / 96), (int)(height * Dpi / 96), Dpi, Dpi, PixelFormats.Pbgra32);
            bitmap.Render(host);
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var output = File.Create($"artifacts/design-tokens/{name}-{width}.png"); encoder.Save(output);
        }
    }
}
