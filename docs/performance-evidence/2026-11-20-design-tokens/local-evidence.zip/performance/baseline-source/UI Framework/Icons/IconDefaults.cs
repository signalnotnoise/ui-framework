namespace UI_Framework;

internal static class IconDefaults
{
    internal const double ViewportSize = 24;
    internal const double DisplaySize = 16;
}
