# Paired rendering performance

Baseline: 980618d6470c5ad0210298fb3b3d0b2420b52c37. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 3,837.51 | 3,823.39 | -0.37% | within budget |
| full-list | Milliseconds | 3,233.50 | 3,137.55 | -2.97% | within budget |
| full-list | MountAllocatedBytes | 333,483,728.00 | 333,519,040.00 | 0.01% | within budget |
| full-list | AllocatedBytes | 468,934,000.00 | 469,554,208.00 | 0.13% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 424.25 | 416.58 | -1.81% | within budget |
| virtualized | Milliseconds | 403.23 | 402.13 | -0.27% | within budget |
| virtualized | MountAllocatedBytes | 9,595,984.00 | 9,595,624.00 | -0.00% | within budget |
| virtualized | AllocatedBytes | 48,887,464.00 | 48,887,352.00 | -0.00% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 165.00 | 165.00 | 0.00% | within budget |
| virtualized | Mounts | 69.00 | 69.00 | 0.00% | within budget |
| virtualized | Unmounts | 66.00 | 66.00 | 0.00% | within budget |
| themed-full-list | MountMilliseconds | 3,665.20 | 3,629.86 | -0.96% | within budget |
| themed-full-list | Milliseconds | 3,630.26 | 3,469.25 | -4.44% | within budget |
| themed-full-list | MountAllocatedBytes | 329,073,816.00 | 328,991,080.00 | -0.03% | within budget |
| themed-full-list | AllocatedBytes | 473,673,512.00 | 474,330,272.00 | 0.14% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
