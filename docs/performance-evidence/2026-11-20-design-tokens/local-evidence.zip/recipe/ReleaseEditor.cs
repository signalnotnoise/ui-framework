using UI_Framework;
using static UI_Framework.UI;

public sealed class ReleaseEditor : Component
{
    public ThemeTokens Theme { get; set; } = new();
    private readonly State<string> title = new("Autumn release");
    public Action<string> Save { get; set; } = _ => { };

    public override View Body() => VStack(
        Text("Release details").FontSize(Theme.Typography.Heading),
        Text("Give your team a clear next milestone.").FontSize(Theme.Typography.Body),
        Text("Release name").FontSize(Theme.Typography.Caption),
        TextField(title).FontSize(Theme.Typography.Body).AccessibilityLabel("Release name"),
        Button("Save release", () => Save(title.Value))
            .FontSize(Theme.Typography.Body).ButtonStyle(ButtonStyleKind.Primary)
    ).Spacing(Theme.Spacing.Medium).Padding(Theme.Spacing.ExtraLarge);
}
