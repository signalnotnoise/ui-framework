using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using UI_Framework;
using UI_Framework.Wpf;

[TestClass]
public sealed class ContrastThemeTests
{
    [TestMethod]
    public void SystemEventRegistrationDoesNotRetainUnusedPalette() => StaTestRunner.Run(() =>
    {
        var weak = CreateReleasedPalette();
        for (var i = 0; i < 3 && weak.IsAlive; i++)
        {
            GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
        }
        Assert.IsFalse(weak.IsAlive);
    });

    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private static WeakReference CreateReleasedPalette()
    {
        var root = new StackPanel();
        ThemeStyles.Apply(root, new ThemeTokens());
        return new WeakReference(root.Resources[ThemePalette.ResourceKey]);
    }

    [TestMethod]
    public void LivePaletteChangesPreserveKeyboardFocusAndPopupSelection() => StaTestRunner.Run(() =>
    {
        var editor = new TextBox { Text = "composition owner" };
        var picker = new ComboBox { ItemsSource = new[] { "One", "Two" }, SelectedIndex = 1 };
        var panel = new StackPanel(); panel.Children.Add(editor); panel.Children.Add(picker);
        ThemeStyles.Apply(panel, new ThemeTokens());
        var window = new Window { Content = panel, Width = 400, Height = 300, ShowInTaskbar = false };
        try
        {
            window.Show(); window.Activate(); TestVisualTree.Layout(panel);
            editor.Focus(); editor.Select(1, 3);
            Assert.IsTrue(editor.IsKeyboardFocused);
            var palette = (ThemePalette)panel.Resources[ThemePalette.ResourceKey];
            palette.Refresh(true); TestVisualTree.Flush();
            Assert.IsTrue(editor.IsKeyboardFocused);
            Assert.AreEqual(1, editor.SelectionStart); Assert.AreEqual(3, editor.SelectionLength);
            picker.IsDropDownOpen = true; TestVisualTree.Flush();
            var popup = (Border)picker.Template.FindName("DropDownChrome", picker);
            Assert.AreEqual(SystemColors.WindowColor, ((SolidColorBrush)popup.Background).Color);
            var item = (ComboBoxItem)picker.ItemContainerGenerator.ContainerFromIndex(1);
            Assert.AreEqual(SystemColors.HighlightColor, ((SolidColorBrush)item.Background).Color);
            Assert.AreEqual(SystemColors.HighlightTextColor, ((SolidColorBrush)item.Foreground).Color);
            palette.Refresh(false); TestVisualTree.Flush();
            Assert.IsTrue(picker.IsDropDownOpen); Assert.AreEqual(1, picker.SelectedIndex);
        }
        finally { window.Close(); }
    });

    [TestMethod]
    public void PaletteTransitionRetainsTemplatesTextSelectionAndLocalOverrides() => StaTestRunner.Run(() =>
    {
        var panel = new StackPanel();
        var editor = new TextBox { Text = "retained text" };
        var button = new Button { Content = "Action" };
        var disabled = new Button { Content = "Disabled", IsEnabled = false };
        var toggle = new CheckBox { Content = "Checked", IsChecked = true };
        var picker = new ComboBox { ItemsSource = new[] { "One", "Two" }, SelectedIndex = 1 };
        panel.Children.Add(editor); panel.Children.Add(button); panel.Children.Add(disabled);
        panel.Children.Add(toggle); panel.Children.Add(picker);
        var theme = new ThemeTokens();
        ThemeStyles.Apply(panel, theme);
        TestVisualTree.Layout(panel);
        editor.Select(2, 4);
        var template = editor.Template;
        var content = editor.Template.FindName("PART_ContentHost", editor);
        var palette = (ThemePalette)panel.Resources[ThemePalette.ResourceKey];
        palette.Refresh(true);
        TestVisualTree.Flush();
        Assert.AreEqual(SystemColors.WindowColor, ((SolidColorBrush)editor.Background).Color);
        Assert.AreEqual(SystemColors.WindowTextColor, ((SolidColorBrush)editor.Foreground).Color);
        Assert.AreEqual(SystemColors.GrayTextColor, ((SolidColorBrush)disabled.Foreground).Color);
        Assert.AreEqual(1d, disabled.Opacity);
        Assert.AreSame(template, editor.Template);
        Assert.AreSame(content, editor.Template.FindName("PART_ContentHost", editor));
        Assert.AreEqual(2, editor.SelectionStart); Assert.AreEqual(4, editor.SelectionLength);
        Assert.AreEqual("retained text", editor.Text);
        Assert.AreEqual(1, picker.SelectedIndex); Assert.IsTrue(toggle.IsChecked);
        button.Foreground = Brushes.Magenta;
        palette.Refresh(false);
        TestVisualTree.Flush();
        Assert.AreEqual((Color)ColorConverter.ConvertFromString(theme.Surface), ((SolidColorBrush)editor.Background).Color);
        Assert.AreSame(Brushes.Magenta, button.Foreground);
        ThemeStyles.Apply(panel, theme with { Surface = "#123456" });
        palette.Refresh(true); // A queued notification for the replaced scope must be inert.
        TestVisualTree.Flush();
        Assert.AreEqual(Color.FromRgb(18, 52, 86), ((SolidColorBrush)editor.Background).Color);
    });
}
