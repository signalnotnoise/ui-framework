using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using UI_Framework;

namespace UI_Framework.Wpf;

/// <summary>Dispatcher-owned brushes; system events retain only weak palette references.</summary>
internal sealed class ThemePalette
{
    private static readonly object Gate = new();
    private static readonly List<WeakReference<ThemePalette>> Palettes = [];
    internal static readonly object ResourceKey = new();
    private readonly Dispatcher dispatcher = Dispatcher.CurrentDispatcher;
    private readonly Dictionary<string, Color> colors = [];
    private readonly ResourceDictionary resources;
    private bool active = true;

    static ThemePalette()
    {
        SystemParameters.StaticPropertyChanged += (_, _) => RefreshAll();
        SystemEvents.UserPreferenceChanged += (_, _) => RefreshAll();
    }

    internal ThemePalette(ThemeTokens theme, ResourceDictionary resources)
    {
        this.resources = resources;
        foreach (var property in typeof(ThemeTokens).GetProperties())
            if (property.PropertyType == typeof(string))
            {
                var color = (Color)ColorConverter.ConvertFromString((string)property.GetValue(theme)!);
                colors.Add(property.Name, color);
            }
        Refresh(SystemParameters.HighContrast);
        lock (Gate)
        {
            Palettes.RemoveAll(reference => !reference.TryGetTarget(out _));
            Palettes.Add(new(this));
        }
    }

    internal DynamicResourceExtension this[string role] => new((typeof(ThemePalette), role));

    internal void Deactivate() => active = false;

    internal void Refresh(bool contrast)
    {
        dispatcher.VerifyAccess();
        if (!active) return;
        foreach (var (role, entry) in colors)
        {
            var color = !contrast ? entry : role switch
            {
                nameof(ThemeTokens.Ink) or nameof(ThemeTokens.Border) => SystemColors.WindowTextColor,
                nameof(ThemeTokens.Muted) => SystemColors.GrayTextColor,
                nameof(ThemeTokens.Focus) or nameof(ThemeTokens.Accent) or nameof(ThemeTokens.AccentHover) or nameof(ThemeTokens.AccentPressed) => SystemColors.HighlightColor,
                nameof(ThemeTokens.OnAccent) => SystemColors.HighlightTextColor,
                _ => SystemColors.WindowColor
            };
            var key = (typeof(ThemePalette), role);
            if (resources[key] is SolidColorBrush existing && existing.Color == color) continue;
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            resources[key] = brush;
        }
    }

    private static void RefreshAll()
    {
        lock (Gate)
        {
            Palettes.RemoveAll(reference => !reference.TryGetTarget(out _));
            foreach (var reference in Palettes)
                if (reference.TryGetTarget(out var palette) && !palette.dispatcher.HasShutdownStarted)
                    palette.dispatcher.BeginInvoke(DispatcherPriority.Render, new Action(() =>
                    {
                        if (reference.TryGetTarget(out var current)) current.Refresh(SystemParameters.HighContrast);
                    }));
        }
    }
}
