from pathlib import Path
import json,statistics
p=Path('artifacts/fw007-guarded')
f=p/'performance/summary.json'
if f.exists():
 d=json.loads(f.read_text(encoding='utf-8-sig')); print('Broad passed:',d['passed']);print('Failing:',[(x['scenario'],x['metric'],x['changePercent']) for x in d['comparisons'] if x['regression']])
 for x in d['comparisons']:
  if x['scenario']=='virtualized':print(x['metric'],x['baselineMedian'],x['candidateMedian'],x['changePercent'])
for name in ['layout','full-layout']:
 f=p/name/'comparison.json'
 if not f.exists():continue
 d=json.loads(f.read_text(encoding='utf-8-sig')); print(name)
 for count,scenario in sorted({(x['count'],x['scenario']) for x in d['results']}):
  groups=[[x for x in d['results'] if x['count']==count and x['scenario']==scenario and x['side']==side and not x['warmup']] for side in ['baseline','candidate']]
  a,b=[statistics.median(x['milliseconds'] for x in g) for g in groups]
  print(count,scenario,a,b,100*(b/a-1),[{k:statistics.median(x[k] for x in g) for k in ['mountMilliseconds','mountAllocated','allocated','builds','mounts','unmounts','nativeEditors']} for g in groups])
