using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace UI_Framework.Wpf;

internal sealed class VirtualRowPresenter : ContentControl
{
    private VirtualRow? row;
    private ViewHost? host;
    private DispatcherOperation? focusOperation;
    private TextComposition? composition;
    private Exception? compositionFailure;

    static VirtualRowPresenter()
    {
        EventManager.RegisterClassHandler(typeof(VirtualRowPresenter), TextCompositionManager.PreviewTextInputStartEvent,
            new TextCompositionEventHandler(CompositionStarted), true);
        EventManager.RegisterClassHandler(typeof(VirtualRowPresenter), TextCompositionManager.PreviewTextInputUpdateEvent,
            new TextCompositionEventHandler(CompositionStarted), true);
        EventManager.RegisterClassHandler(typeof(VirtualRowPresenter), TextCompositionManager.PreviewTextInputEvent,
            new TextCompositionEventHandler(CompositionFinished), true);
    }

    private static void CompositionStarted(object sender, TextCompositionEventArgs args) =>
        ((VirtualRowPresenter)sender).composition = args.TextComposition;

    private static void CompositionFinished(object sender, TextCompositionEventArgs args)
    {
        var presenter = (VirtualRowPresenter)sender;
        if (ReferenceEquals(presenter.composition, args.TextComposition)) presenter.composition = null;
    }

    private void CompleteComposition()
    {
        var active = composition;
        composition = null;
        // Use the virtual provider method: TSF/IME compositions must finish through
        // their provider before their original editor and binding are detached.
        try { active?.Complete(); }
        catch (Exception error) { compositionFailure = error; }
    }

    internal void Attach(VirtualRow value, double gap)
    {
        Release();
        row = value;
        row.Presenter = this;
        Margin = new Thickness(0, 0, 0, gap);
        HorizontalContentAlignment = HorizontalAlignment.Stretch;
        try { host = new ViewHost(() => value.View, value.Saved); }
        catch { row.Presenter = null; row = null; throw; }
        value.Saved = null;
        Content = host;
        if (value.Focus is { } focus)
        {
            value.Focus = null;
            var attachedHost = host;
            focusOperation = Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
            {
                focusOperation = null;
                if (ReferenceEquals(row, value) && ReferenceEquals(host, attachedHost)
                    && !IsKeyboardFocusWithin && (Keyboard.FocusedElement is null
                        || focus.Owns(Keyboard.FocusedElement)
                        || ReferenceEquals(Keyboard.FocusedElement, Window.GetWindow(this))))
                    focus.Restore(this);
            }));
        }
    }

    internal void Refresh(double gap)
    {
        Margin = new Thickness(0, 0, 0, gap);
        host?.Refresh();
    }

    internal void Deactivate()
    {
        CompleteComposition();
        host?.Deactivate();
    }
    internal NodeSnapshot? Capture() => host?.Capture();

    internal void Release()
    {
        focusOperation?.Abort();
        focusOperation = null;
        if (row is null) return;
        var previous = row;
        row = null;
        var old = host;
        host = null;
        previous.Presenter = null;
        Exception? failure = null;
        try
        {
            CompleteComposition();
            var completionError = compositionFailure;
            compositionFailure = null;
            if (completionError is not null)
                System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(completionError).Throw();
            previous.Focus = IsKeyboardFocusWithin ? RowFocusSnapshot.Capture(this) : null;
            previous.Saved = old?.Capture();
        }
        catch (Exception error) { previous.Saved = null; previous.Focus = null; failure = error; }
        Content = null;
        try { old?.Dispose(); }
        catch (Exception error)
        {
            if (failure is not null) throw new AggregateException("Row capture and cleanup failed.", failure, error);
            throw;
        }
        if (failure is not null) System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(failure).Throw();
    }
}
