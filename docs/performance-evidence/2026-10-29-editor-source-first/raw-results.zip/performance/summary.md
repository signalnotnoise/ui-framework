# Paired rendering performance

Baseline: 78c88fb901c202e3c2e49b6de300d1ce2369e00b. Samples per side: 7. Negative change is an improvement.

| Scenario | Metric | Baseline median | Candidate median | Change | Result |
| --- | --- | ---: | ---: | ---: | --- |
| full-list | MountMilliseconds | 5,709.16 | 5,815.61 | 1.86% | within budget |
| full-list | Milliseconds | 8,526.26 | 7,220.19 | -15.32% | within budget |
| full-list | MountAllocatedBytes | 336,480,512.00 | 332,967,536.00 | -1.04% | within budget |
| full-list | AllocatedBytes | 618,964,264.00 | 463,238,768.00 | -25.16% | within budget |
| full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| virtualized | MountMilliseconds | 426.59 | 424.84 | -0.41% | within budget |
| virtualized | Milliseconds | 830.82 | 415.07 | -50.04% | within budget |
| virtualized | MountAllocatedBytes | 9,692,392.00 | 9,538,416.00 | -1.59% | within budget |
| virtualized | AllocatedBytes | 63,211,160.00 | 47,885,312.00 | -24.25% | within budget |
| virtualized | MountBodyBuilds | 27.00 | 27.00 | 0.00% | within budget |
| virtualized | BodyBuilds | 194.00 | 165.00 | -14.95% | within budget |
| virtualized | Mounts | 98.00 | 69.00 | -29.59% | within budget |
| virtualized | Unmounts | 95.00 | 66.00 | -30.53% | within budget |
| themed-full-list | MountMilliseconds | 5,537.33 | 6,309.20 | 13.94% | REGRESSION |
| themed-full-list | Milliseconds | 18,626.61 | 7,875.20 | -57.72% | within budget |
| themed-full-list | MountAllocatedBytes | 327,592,704.00 | 327,814,136.00 | 0.07% | within budget |
| themed-full-list | AllocatedBytes | 1,064,222,408.00 | 469,554,872.00 | -55.88% | within budget |
| themed-full-list | MountBodyBuilds | 1,022.00 | 1,022.00 | 0.00% | within budget |
| themed-full-list | BodyBuilds | 5,141.00 | 5,141.00 | 0.00% | within budget |
| themed-full-list | Mounts | 456.00 | 456.00 | 0.00% | within budget |
| themed-full-list | Unmounts | 658.00 | 658.00 | 0.00% | within budget |
| layout-editors | MountMilliseconds | 1,953.94 | 2,168.20 | 10.97% | REGRESSION |
| layout-editors | Milliseconds | 21,582.29 | 19,564.27 | -9.35% | within budget |
| layout-editors | MountAllocatedBytes | 125,471,128.00 | 120,723,008.00 | -3.78% | within budget |
| layout-editors | AllocatedBytes | 1,156,424,600.00 | 1,112,710,280.00 | -3.78% | within budget |
| layout-editors | MountBodyBuilds | 1.00 | 1.00 | 0.00% | within budget |
| layout-editors | BodyBuilds | 50.00 | 50.00 | 0.00% | within budget |
| layout-editors | Mounts | 0.00 | 0.00 | 0.00% | within budget |
| layout-editors | Unmounts | 0.00 | 0.00 | 0.00% | within budget |
